# Analyse how the furnishing status affects the rent amount across different cities.

install.packages("readxl")
install.packages("dplyr")
install.packages("ggplot2")
install.packages("GGally")
install.packages("plotly")
install.packages("corrplot")
library(dplyr)
library(ggplot2)
library(GGally)
library(plotly)
library(corrplot)

#Import dataset
HouseRent = read.csv("D:\\Microsoft Teams\\Degree Year2 Sem1\\PFDA\\House_Rent_Dataset.csv")
HouseRent #Show data in console
names(HouseRent) # Show all Column name
View(HouseRent)#Show data in table form
unique(HouseRent$Furnishing.Status) #Show different data in column Furnishing Status
unique(HouseRent$City)
unique(HouseRent$Floor)
unique(HouseRent$Tenant.Preferred)
unique(HouseRent$Area.Locality)
unique(HouseRent$Area.Type)
unique(HouseRent$Point.of.Contact)

###################DATA CLEANING AND OUTLIER REPLACEMENT##################################
#Check null value
colSums(is.na(HouseRent))

#Check duplicate row
sum(duplicated(HouseRent))

unique(HouseRent$City)
unique_cities = unique(HouseRent$City)

city_subsets <- setNames(replicate(length(unique_cities), NULL), unique_cities)
city_subsets

for(i in unique_cities){
  city_subset = HouseRent %>% filter(City == i)
  city_subsets[[i]] = city_subset
}
city_subsets

city_subsets_unclean = city_subsets

#_______________________________________________________________________________________________________
#Cleaning part for rent
{#Cleaning for Kolkata Rent
  max(city_subsets$Kolkata$Rent)
  city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Rent !=180000, ]
  city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Rent !=65000, ]
  city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Rent !=60000, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Kolkata$Rent)
  boxplot(city_subsets$Kolkata$Rent)
  
  head(city_subsets$Kolkata[order(city_subsets$Kolkata$Rent, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Mumbai Rent
  max(city_subsets$Mumbai$Rent)
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=1200000, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=1000000, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=850000, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=700000, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=680000, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=650000, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=600000, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=500000, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=450000, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Mumbai$Rent)
  boxplot(city_subsets$Mumbai$Rent)
  
  head(city_subsets$Mumbai[order(city_subsets$Mumbai$Rent, decreasing = TRUE), ], 10)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Bangalore Rent
  max(city_subsets$Bangalore$Rent)
  city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=3500000, ]
  city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=380000, ]
  city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=280000, ]
  city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=250000, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Bangalore$Rent)
  boxplot(city_subsets$Bangalore$Rent)
  
  head(city_subsets$Bangalore[order(city_subsets$Bangalore$Rent, decreasing = TRUE), ], 10)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Delhi Rent
  max(city_subsets$Delhi$Rent)
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=530000, ]
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=350000, ]
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=280000, ]
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=260000, ]
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=250000, ]
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=200000, ]
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=190000, ]
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=150000, ]
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=140000, ]
  city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=130000, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Delhi$Rent)
  boxplot(city_subsets$Delhi$Rent)
  
  head(city_subsets$Delhi[order(city_subsets$Delhi$Rent, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Chennai Rent
  max(city_subsets$Chennai$Rent)
  city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=600000, ]
  city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=330000, ]
  city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=280000, ]
  city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=250000, ]
  city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=220000, ]
  city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=200000, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Chennai$Rent)
  boxplot(city_subsets$Chennai$Rent)
  
  head(city_subsets$Chennai[order(city_subsets$Chennai$Rent, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Hyderabad Rent
  max(city_subsets$Hyderabad$Rent)
  city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=400000, ]
  city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=300000, ]
  city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=250000, ]
  city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=200000, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Hyderabad$Rent)
  boxplot(city_subsets$Hyderabad$Rent)
  
  head(city_subsets$Hyderabad[order(city_subsets$Hyderabad$Rent, decreasing = TRUE), ], 20)
} 

#Cleaning part for Size
{#Cleaning for Kolkata Size
  max(city_subsets$Kolkata$Size)
  city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Size!=4000, ]
  city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Size!=3500, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Kolkata$Size)
  boxplot(city_subsets$Kolkata$Size)
  
  head(city_subsets$Kolkata[order(city_subsets$Kolkata$Size, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Mumbai Size
  max(city_subsets$Mumbai$Size)
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Size !=3700, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Size !=3250, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Mumbai$Size)
  boxplot(city_subsets$Mumbai$Size)
  
  head(city_subsets$Mumbai[order(city_subsets$Mumbai$Size, decreasing = TRUE), ], 10)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Bangalore Size
  max(city_subsets$Bangalore$Size)
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Bangalore$Size)
  boxplot(city_subsets$Bangalore$Size)
  
  head(city_subsets$Bangalore[order(city_subsets$Bangalore$Size, decreasing = TRUE), ], 10)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Delhi Size
  max(city_subsets$Delhi$Size)
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Delhi$Size)
  boxplot(city_subsets$Delhi$Size)
  
  head(city_subsets$Delhi[order(city_subsets$Delhi$Size, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Chennai Size
  max(city_subsets$Chennai$Size)
  city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Size !=6000, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Chennai$Size)
  boxplot(city_subsets$Chennai$Size)
  
  head(city_subsets$Chennai[order(city_subsets$Chennai$Size, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Hyderabad Size
  max(city_subsets$Hyderabad$Size)
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Hyderabad$Size)
  boxplot(city_subsets$Hyderabad$Size)
  
  head(city_subsets$Hyderabad[order(city_subsets$Hyderabad$Size, decreasing = TRUE), ], 20)
}

#_______________________________________________________________________________________________________
#Comparison before cleaning and after cleaning
#Unclean distribution data of Rent in each city and Furnishing status
custom_breaks <- seq(500000, max(HouseRent$Rent), by = 500000)

ggplot(HouseRent, aes(x = City, y = Rent, fill = factor(Furnishing.Status))) +
  geom_bar(stat = "identity", position = "dodge", color="Black") +
  ggtitle("Rent Distribution by City and Furnishing Status") +
  labs(x = "City", y = "Rent") +
  scale_fill_discrete(name = "Furnishing Status") +
  scale_y_continuous(breaks = custom_breaks) +
  theme_minimal()

HouseRent_Cleaned = do.call(rbind, city_subsets)

ggplot(HouseRent_Cleaned, aes(x = City, y = Rent, fill = factor(Furnishing.Status))) +
  geom_bar(stat = "identity", position = "dodge", color="Black") +
  ggtitle("Rent Distribution by City and Furnishing Status") +
  labs(x = "City", y = "Rent") +
  scale_fill_discrete(name = "Furnishing Status") +
  scale_y_continuous(breaks = custom_breaks) +
  theme_minimal()

#_______________________________________________________________________________________________________
#Data exploration for categorized data
{
  BHK_Count = as.data.frame(table(HouseRent_Cleaned$BHK))
  names(BHK_Count)[1] = "BHK"
  print(BHK_Count, row.names = FALSE)
  
  ggplot(BHK_Count, aes(x = BHK, y = Freq)) +
    geom_bar(stat = "identity", fill = c("pink", "lightblue","lightyellow", "lightcyan", "#DDA0DD", "lavender"), color = "black") +
    labs(title = "BHK Frequency Counts",
         x = "BHK",
         y = "Frequency") +
    theme_minimal()
  
  plot_ly(BHK_Count, labels =~BHK, values = ~Freq, type = "pie",
          marker = list(colors = c("pink", "lightblue","lightyellow", "lightcyan", "#DDA0DD", "lavender")),
          textinfo = "label+percent",
          hoverinfo = 'text',
          text = ~paste('BHK = ',BHK, '\nFreq = ', Freq))%>%
    layout(showlegend = TRUE,
           legend = list(orientation = 'v', x = 1, y = 0.5),
           title = list(text = "Pie Chart for different number of BHKs", font = list(size = 15)))
  
  Area.Type_Count = as.data.frame(table(HouseRent_Cleaned$Area.Type))
  names(Area.Type_Count)[1] = "Area.Type"
  print(Area.Type_Count, row.names = FALSE)
  
  ggplot(Area.Type_Count, aes(x = Area.Type, y = Freq)) +
    geom_bar(stat = "identity", fill = "pink", color = "black") +
    labs(title = "Area.Type Frequency Counts",
         x = "Area.Type",
         y = "Frequency") +
    theme_minimal()
  
  plot_ly(Area.Type_Count, labels =~Area.Type, values = ~Freq, type = "pie",
          marker = list(colors = c("pink", "lightblue")),
          textinfo = "label+percent",
          hoverinfo = 'text',
          text = ~paste('Area.Type = ',Area.Type, '\nFreq = ', Freq))%>%
    layout(showlegend = TRUE,
           legend = list(orientation = 'v', x = 1, y = 0.5),
           title = list(text = "Pie Chart for different Area type", font = list(size = 15)))
  
  City_Count = as.data.frame(table(HouseRent_Cleaned$City))
  names(City_Count)[1] = "City"
  print(City_Count, row.names = FALSE)
  
  ggplot(City_Count, aes(x = City, y = Freq)) +
    geom_bar(stat = "identity", fill = "lightyellow", color = "black") +
    labs(title = "City Frequency Counts",
         x = "City",
         y = "Frequency") +
    theme_minimal()
  
  plot_ly(City_Count, labels =~City, values = ~Freq, type = "pie",
          marker = list(colors = c("pink", "lightblue","lightyellow", "lightcyan", "#DDA0DD", "lavender")),
          textinfo = "label+percent",
          hoverinfo = 'text',
          text = ~paste('City = ',City, '\nFreq = ', Freq))%>%
    layout(showlegend = TRUE,
           legend = list(orientation = 'v', x = 1, y = 0.5),
           title = list(text = "Pie Chart for different city", font = list(size = 15)))
  
  Furnishing.Status_Count = as.data.frame(table(HouseRent_Cleaned$Furnishing.Status))
  names(Furnishing.Status_Count)[1] = "Furnishing.Status"
  print(Furnishing.Status_Count, row.names = FALSE)
  
  ggplot(Furnishing.Status_Count, aes(x = Furnishing.Status, y = Freq)) +
    geom_bar(stat = "identity", fill = "lightblue", color = "black") +
    labs(title = "Furnishing.Status Frequency Counts",
         x = "Furnishing.Status",
         y = "Frequency") +
    theme_minimal()
  
  plot_ly(Furnishing.Status_Count, labels =~Furnishing.Status, values = ~Freq, type = "pie",
          marker = list(colors = c("pink", "lightblue","lightyellow")),
          textinfo = "label+percent",
          hoverinfo = 'text',
          text = ~paste('Furnishing.Stauts = ',Furnishing.Status, '\nFreq = ', Freq))%>%
    layout(showlegend = TRUE,
           legend = list(orientation = 'v', x = 1, y = 0.5),
           title = list(text = "Pie Chart for different Furnishing Status", font = list(size = 15)))
  
  Tenant.Preferred_Count = as.data.frame(table(HouseRent_Cleaned$Tenant.Preferred))
  names(Tenant.Preferred_Count)[1] = "Tenant.Preferred"
  print(Tenant.Preferred_Count, row.names = FALSE)
  
  ggplot(Tenant.Preferred_Count, aes(x = Tenant.Preferred, y = Freq)) +
    geom_bar(stat = "identity", fill = "pink", color = "black") +
    labs(title = "Tenant.Preferred Frequency Counts",
         x = "Tenant.Preferred",
         y = "Frequency") +
    theme_minimal()
  
  plot_ly(Tenant.Preferred_Count, labels =~Tenant.Preferred, values = ~Freq, type = "pie",
          marker = list(colors = c("pink", "lightblue","lightyellow")),
          textinfo = "label+percent",
          hoverinfo = 'text',
          text = ~paste('Tenant.Preferred = ',Tenant.Preferred, '\nFreq = ', Freq))%>%
    layout(showlegend = TRUE,
           legend = list(orientation = 'v', x = 1, y = 0.5),
           title = list(text = "Pie Chart for different Tenant Preferred", font = list(size = 15)))
  
  Bathroom_Count = as.data.frame(table(HouseRent_Cleaned$Bathroom))
  names(Bathroom_Count)[1] = "Bathroom"
  print(Bathroom_Count, row.names = FALSE)
  
  ggplot(Bathroom_Count, aes(x = Bathroom, y = Freq)) +
    geom_bar(stat = "identity", fill = "cyan", color = "black") +
    labs(title = "Bathroom Frequency Counts",
         x = "Bathroom",
         y = "Frequency") +
    theme_minimal()
  
  plot_ly(Bathroom_Count, labels =~Bathroom, values = ~Freq, type = "pie",
          marker = list(colors = c("pink", "lightblue","lightyellow", "lightcyan", "#DDA0DD", "lavender")),
          textinfo = "label+percent",
          hoverinfo = 'text',
          text = ~paste('Bathroom = ',Bathroom, '\nFreq = ', Freq))%>%
    layout(showlegend = TRUE,
           legend = list(orientation = 'v', x = 1, y = 0.5),
           title = list(text = "Pie Chart for different number of Bathrooms", font = list(size = 15)))
  
  Point.of.Contact_Count = as.data.frame(table(HouseRent_Cleaned$Point.of.Contact))
  names(Point.of.Contact_Count)[1] = "Point.of.Contact"
  print(Point.of.Contact_Count, row.names = FALSE)
  
  ggplot(Point.of.Contact_Count, aes(x = Point.of.Contact, y = Freq)) +
    geom_bar(stat = "identity", fill = "lightyellow", color = "black") +
    labs(title = "Point.of.Contact Frequency Counts",
         x = "Point.of.Contact",
         y = "Frequency") +
    theme_minimal()

  plot_ly(Point.of.Contact_Count, labels =~Point.of.Contact, values = ~Freq, type = "pie",
          marker = list(colors = c("pink", "lightblue","lightyellow", "lightcyan", "#DDA0DD", "lavender")),
          textinfo = "label+percent",
          hoverinfo = 'text',
          text = ~paste('Point.of.Contact = ',Point.of.Contact, '\nFreq = ', Freq))%>%
    layout(showlegend = TRUE,
           legend = list(orientation = 'v', x = 1, y = 0.5),
           title = list(text = "Pie Chart for different point of contact", font = list(size = 15)))
  }

#_______________________________________________________________________________________________________
#Data Visualization
# Create a histogram of Rent
ggplot(HouseRent_Cleaned, aes(x = Rent)) +
  geom_histogram(binwidth = 1000, color = "black", fill = "lightblue") +
  labs(title = "Distribution of Rent",
       x = "Rent",
       y = "Frequency")+
  scale_x_continuous(breaks = seq(0, max(HouseRent_Cleaned$Rent), by = 50000))

#Create a histogram of Size
ggplot(HouseRent_Cleaned, aes(x = Size)) +
  geom_histogram(binwidth = 1000, color = "black", fill = "lightblue") +
  labs(title = "Distribution of Size",
       x = "Size",
       y = "Frequency")+
  scale_x_continuous(breaks = seq(0, max(HouseRent_Cleaned$Size), by = 1000))


#_______________________________________________________________________________________________________
#Data Pre-processing
HouseRent_Cleaned_Preprocessed = HouseRent_Cleaned

HouseRent_Cleaned_Preprocessed <- HouseRent_Cleaned_Preprocessed %>%
  mutate(Area.Type = case_when(
    Area.Type == "Super Area" ~ 0,
    Area.Type == "Carpet Area" ~ 1,
    Area.Type == "Built Area" ~ 2
  ),
  Furnishing.Status = case_when(
    Furnishing.Status == "Unfurnished" ~ 0,
    Furnishing.Status == "Semi-Furnished" ~ 1,
    Furnishing.Status == "Furnished" ~ 2
  ),
  Point.of.Contact = case_when(
    Point.of.Contact == "Contact Owner" ~ 0,
    Point.of.Contact == "Contact Agent" ~ 1,
    Point.of.Contact == "Contact Builder" ~ 2
  ),
  Tenant.Preferred = case_when(
    Tenant.Preferred == "Family" ~ 0,
    Tenant.Preferred == "Bachelors" ~ 1,
    Tenant.Preferred == "Bachelors/Family" ~ 2
  ))

HouseRent_Cleaned_Preprocessed <- select(HouseRent_Cleaned_Preprocessed, -Posted.On, -Floor, -Area.Locality)

city_subsets_preprocessed <- setNames(replicate(length(unique_cities), NULL), unique_cities)

for(i in unique_cities){
  city_subset_preprocessed = HouseRent_Cleaned_Preprocessed %>% filter(City == i)
  city_subsets_preprocessed[[i]] = city_subset_preprocessed
}

#___________________________________________________________________________________________________
#Correlation of each attributes with Rent
{
  #Kolkata
  #Correlation highest: BHK, Size, Bathroom
  ggpairs(city_subsets_preprocessed$Kolkata, columns = c("BHK", "Rent"))#0.554
  ggpairs(city_subsets_preprocessed$Kolkata, columns = c("Size", "Rent"))#0.604
  ggpairs(city_subsets_preprocessed$Kolkata, columns = c("Point.of.Contact", "Rent"))#0.210
  ggpairs(city_subsets_preprocessed$Kolkata, columns = c("Furnishing.Status", "Rent"))#0.119
  ggpairs(city_subsets_preprocessed$Kolkata, columns = c("Tenant.Preferred", "Rent"))#-0.065
  ggpairs(city_subsets_preprocessed$Kolkata, columns = c("Bathroom", "Rent"))#0.562
  ggpairs(city_subsets_preprocessed$Kolkata, columns = c("Area.Type", "Rent"))#0.027
  
  HouseRent_Cleaned_Preprocessed_Kolkata = city_subsets_preprocessed$Kolkata
  HouseRent_Cleaned_Preprocessed_Kolkata <- select(HouseRent_Cleaned_Preprocessed_Kolkata, -City)
  
  cor_matrix_Kolkata = cor(HouseRent_Cleaned_Preprocessed_Kolkata)
  
  corrplot(cor_matrix_Kolkata, method = "color", addCoef.col = "black", tl.col = "black")
  
  title("Correlation Heatmap for Kolkata", line = 3)
  #___________________________________________________________________________________________________
  #Mumbai
  #Correlation highest: BHK, Size, Bathroom
  ggpairs(city_subsets_preprocessed$Mumbai, columns = c("BHK", "Rent"))#0.733
  ggpairs(city_subsets_preprocessed$Mumbai, columns = c("Size", "Rent"))#0.860
  ggpairs(city_subsets_preprocessed$Mumbai, columns = c("Point.of.Contact", "Rent"))#0.297
  ggpairs(city_subsets_preprocessed$Mumbai, columns = c("Furnishing.Status", "Rent"))#0.260
  ggpairs(city_subsets_preprocessed$Mumbai, columns = c("Tenant.Preferred", "Rent"))#-0.001
  ggpairs(city_subsets_preprocessed$Mumbai, columns = c("Bathroom", "Rent"))#0.740
  ggpairs(city_subsets_preprocessed$Mumbai, columns = c("Area.Type", "Rent"))#0.216
  
  HouseRent_Cleaned_Preprocessed_Mumbai = city_subsets_preprocessed$Mumbai
  HouseRent_Cleaned_Preprocessed_Mumbai <- select(HouseRent_Cleaned_Preprocessed_Mumbai, -City)
  
  cor_matrix_Mumbai = cor(HouseRent_Cleaned_Preprocessed_Mumbai)
  
  corrplot(cor_matrix_Mumbai, method = "color", addCoef.col = "black", tl.col = "black")
  
  title("Correlation Heatmap for Mumbai", line = 3)
  #___________________________________________________________________________________________________
  #Bangalore
  #Correlation highest: BHK, Size, Bathroom
  ggpairs(city_subsets_preprocessed$Bangalore, columns = c("BHK", "Rent"))#0.620
  ggpairs(city_subsets_preprocessed$Bangalore, columns = c("Size", "Rent"))#0.820
  ggpairs(city_subsets_preprocessed$Bangalore, columns = c("Point.of.Contact", "Rent"))#0.482
  ggpairs(city_subsets_preprocessed$Bangalore, columns = c("Furnishing.Status", "Rent"))#0.151
  ggpairs(city_subsets_preprocessed$Bangalore, columns = c("Tenant.Preferred", "Rent"))#-0.174
  ggpairs(city_subsets_preprocessed$Bangalore, columns = c("Bathroom", "Rent"))#0.674
  ggpairs(city_subsets_preprocessed$Bangalore, columns = c("Area.Type", "Rent"))#0.254
  
  HouseRent_Cleaned_Preprocessed_Bangalore = city_subsets_preprocessed$Bangalore
  HouseRent_Cleaned_Preprocessed_Bangalore <- select(HouseRent_Cleaned_Preprocessed_Bangalore, -City)
  
  cor_matrix_Bangalore = cor(HouseRent_Cleaned_Preprocessed_Bangalore)
  
  corrplot(cor_matrix_Bangalore, method = "color", addCoef.col = "black", tl.col = "black")
  
  title("Correlation Heatmap for Bangalore", line = 3)
  
  #___________________________________________________________________________________________________
  #Delhi
  #Correlation highest: BHK, Size, Bathroom
  ggpairs(city_subsets_preprocessed$Delhi, columns = c("BHK", "Rent"))#0.588
  ggpairs(city_subsets_preprocessed$Delhi, columns = c("Size", "Rent"))#0.615
  ggpairs(city_subsets_preprocessed$Delhi, columns = c("Point.of.Contact", "Rent"))#0.353
  ggpairs(city_subsets_preprocessed$Delhi, columns = c("Furnishing.Status", "Rent"))#0.147
  ggpairs(city_subsets_preprocessed$Delhi, columns = c("Tenant.Preferred", "Rent"))#-0.191
  ggpairs(city_subsets_preprocessed$Delhi, columns = c("Bathroom", "Rent"))#0.718
  ggpairs(city_subsets_preprocessed$Delhi, columns = c("Area.Type", "Rent"))#0.224
  
  HouseRent_Cleaned_Preprocessed_Delhi = city_subsets_preprocessed$Delhi
  HouseRent_Cleaned_Preprocessed_Delhi <- select(HouseRent_Cleaned_Preprocessed_Delhi, -City)
  
  cor_matrix_Delhi = cor(HouseRent_Cleaned_Preprocessed_Delhi)
  
  corrplot(cor_matrix_Delhi, method = "color", addCoef.col = "black", tl.col = "black")
  
  title("Correlation Heatmap for Delhi", line = 3)
  
  #___________________________________________________________________________________________________
  #Chennai
  #Correlation highest: BHK, Size, Bathroom
  ggpairs(city_subsets_preprocessed$Chennai, columns = c("BHK", "Rent"))#0.583
  ggpairs(city_subsets_preprocessed$Chennai, columns = c("Size", "Rent"))#0.738
  ggpairs(city_subsets_preprocessed$Chennai, columns = c("Point.of.Contact", "Rent"))#0.565
  ggpairs(city_subsets_preprocessed$Chennai, columns = c("Furnishing.Status", "Rent"))#0.251
  ggpairs(city_subsets_preprocessed$Chennai, columns = c("Tenant.Preferred", "Rent"))#-0.119
  ggpairs(city_subsets_preprocessed$Chennai, columns = c("Bathroom", "Rent"))#0.587
  ggpairs(city_subsets_preprocessed$Chennai, columns = c("Area.Type", "Rent"))#0.181
  
  HouseRent_Cleaned_Preprocessed_Chennai = city_subsets_preprocessed$Chennai
  HouseRent_Cleaned_Preprocessed_Chennai <- select(HouseRent_Cleaned_Preprocessed_Chennai, -City)
  
  cor_matrix_Chennai = cor(HouseRent_Cleaned_Preprocessed_Chennai)
  
  corrplot(cor_matrix_Chennai, method = "color", addCoef.col = "black", tl.col = "black")
  
  title("Correlation Heatmap for Chennai", line = 3)
  
  #___________________________________________________________________________________________________
  #Hyderabad
  #Correlation highest: BHK, Size, Bathroom
  ggpairs(city_subsets_preprocessed$Hyderabad, columns = c("BHK", "Rent"))#0.593
  ggpairs(city_subsets_preprocessed$Hyderabad, columns = c("Size", "Rent"))#0.732
  ggpairs(city_subsets_preprocessed$Hyderabad, columns = c("Point.of.Contact", "Rent"))#0.521
  ggpairs(city_subsets_preprocessed$Hyderabad, columns = c("Furnishing.Status", "Rent"))#0.267
  ggpairs(city_subsets_preprocessed$Hyderabad, columns = c("Tenant.Preferred", "Rent"))#-0.227
  ggpairs(city_subsets_preprocessed$Hyderabad, columns = c("Bathroom", "Rent"))#0.626
  ggpairs(city_subsets_preprocessed$Hyderabad, columns = c("Area.Type", "Rent"))#0.226
  
  HouseRent_Cleaned_Preprocessed_Hyderabad = city_subsets_preprocessed$Hyderabad
  HouseRent_Cleaned_Preprocessed_Hyderabad <- select(HouseRent_Cleaned_Preprocessed_Hyderabad, -City)
  
  cor_matrix_Hyderabad = cor(HouseRent_Cleaned_Preprocessed_Hyderabad)
  
  corrplot(cor_matrix_Hyderabad, method = "color", addCoef.col = "black", tl.col = "black")
  
  title("Correlation Heatmap for Hyderabad", line = 3)
}
#_______________________________________________________________________________________________________
#ANOVA
{
  #ANOVA for Kolkata
  #Result for p-value in Kolkata
  summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#2*10^(-16)
  summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#2*10^(-16)
  summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#1.38*10^(-6)
  summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#0.00642
  summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#0.137
  summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#2*10^(-16)
  summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))# 0.545
  
  ANOVA_attribute <- c("BHK", "Size", "Point.of.Contact", "Furnishing.Status", "Tenant.Preferred", "Bathroom", "Area.Type")
  ANOVA_p_scores_Kolkata <- c(2 * 10^(-16), 2 * 10^(-16), 1.38 * 10^(-6), 0.00642, 0.137, 2 * 10^(-16), 0.545)
  ANOVA_p_scores_df_Kolkata <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Kolkata)
  
  ggplot(ANOVA_p_scores_df_Kolkata, aes(x = Attribute, y = P_Value)) +
    geom_bar(stat = "identity", fill = "blue") +
    labs(title = "ANOVA P-Values for Each Attribute in Kolkata",
         x = "Attribute", y = "P-Value") +
    scale_y_log10()
  #_______________________________________________________________________________________________________
  #ANOVA for Mumbai
  #Result for p-value in Mumbai
  summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2*10^(-16)
  summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2*10^(-16)
  summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2*10^(-16)
  summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2.75*10^(-16)
  summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#0.98
  summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2*10^(-16)
  summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#1.26*10^(-11)
  
  ANOVA_p_scores_Mumbai <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 2.75 * 10^(-16), 0.98, 2 * 10^(-16), 1.26 * 10^(-11))
  ANOVA_p_scores_df_Mumbai <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Mumbai)
  
  ggplot(ANOVA_p_scores_df_Mumbai, aes(x = Attribute, y = P_Value)) +
    geom_bar(stat = "identity", fill = "blue") +
    labs(title = "ANOVA P-Values for Each Attribute in Mumbai",
         x = "Attribute", y = "P-Value") +
    scale_y_log10()
  #_______________________________________________________________________________________________________
  #ANOVA for Bangalore
  #Result for p-value in Bangalore
  summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#2*10^(-16)
  summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#2*10^(-16)
  summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#2*10^(-16)
  summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#6.42*10^(-6)
  summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#1.95*10^(-7)
  summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#2*10^(-16)
  summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#1.78*10^(-14)
  
  ANOVA_p_scores_Bangalore <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 6.42*10^(-6), 1.95*10^(-7), 2*10^(-16), 1.78*10^(-14))
  ANOVA_p_scores_df_Bangalore <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Bangalore)
  
  ggplot(ANOVA_p_scores_df_Bangalore, aes(x = Attribute, y = P_Value)) +
    geom_bar(stat = "identity", fill = "blue") +
    labs(title = "ANOVA P-Values for Each Attribute in Bangalore",
         x = "Attribute", y = "P-Value") +
    scale_y_log10()
  
  #_______________________________________________________________________________________________________
  #ANOVA for Delhi
  #Result for p-value in Delhi
  summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#2*10^(-16)
  summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#2*10^(-16)
  summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#2*10^(-16)
  summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#0.00035
  summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#3.22*10^(-6)
  summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#2*10^(-16)
  summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#4.29*10^(-8)
  
  ANOVA_p_scores_Delhi <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 0.00035, 3.22*10^(-6), 2*10^(-16), 4.29*10^(-8))
  ANOVA_p_scores_df_Delhi <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Delhi)
  
  ggplot(ANOVA_p_scores_df_Delhi, aes(x = Attribute, y = P_Value)) +
    geom_bar(stat = "identity", fill = "blue") +
    labs(title = "ANOVA P-Values for Each Attribute in Delhi",
         x = "Attribute", y = "P-Value") +
    scale_y_log10()
  
  #_______________________________________________________________________________________________________
  #ANOVA for Chennai
  #Result for p-value in Chennai
  summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#2*10^(-16)
  summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#2*10^(-16)
  summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#2*10^(-16)
  summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#3.83*10^(-14)
  summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#0.000389
  summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#2*10^(-16)
  summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#6.39*10^(-8)
  
  ANOVA_p_scores_Chennai <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 3.83*10^(-14), 0.000389, 2 * 10^(-16), 6.39*10^(-8))
  ANOVA_p_scores_df_Chennai <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Chennai)
  
  ggplot(ANOVA_p_scores_df_Chennai, aes(x = Attribute, y = P_Value)) +
    geom_bar(stat = "identity", fill = "blue") +
    labs(title = "ANOVA P-Values for Each Attribute in Chennai",
         x = "Attribute", y = "P-Value") +
    scale_y_log10()
  
  #_______________________________________________________________________________________________________
  #ANOVA for Hyderabad
  #Result for p-value in Hyderabad
  summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
  summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
  summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
  summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#1.34*10^(-15)
  summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
  summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
  summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#1.85*10^(-11)
  
  ANOVA_p_scores_Hyderabad <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 1.34*10^(-15), 2*10^(-16), 2 * 10^(-16), 1.85*10^(-11))
  ANOVA_p_scores_df_Hyderabad <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Hyderabad)
  
  ggplot(ANOVA_p_scores_df_Hyderabad, aes(x = Attribute, y = P_Value)) +
    geom_bar(stat = "identity", fill = "blue") +
    labs(title = "ANOVA P-Values for Each Attribute in Hyderabad",
         x = "Attribute", y = "P-Value") +
    scale_y_log10()
}
#_______________________________________________________________________________________________________
#Linear Regression Model

# Set a random seed for reproducibility
set.seed(123)

# Define the proportion of data for the training set (e.g., 70%)
train_proportion <- 0.7

# Calculate the number of samples for the training set
num_train <- round(nrow(HouseRent_Cleaned_Preprocessed) * train_proportion)

# Create an index vector for random sampling
sample_indices <- sample(seq_len(nrow(HouseRent_Cleaned_Preprocessed)), size = num_train)

# Create the training dataset
train_data <- HouseRent_Cleaned_Preprocessed[sample_indices, ]

# Create the testing dataset by excluding samples used in training
test_data <- HouseRent_Cleaned_Preprocessed[-sample_indices, ]

# Train a linear regression model
model <- lm(Rent ~ BHK + Size +  Point.of.Contact + Bathroom +Furnishing.Status + Point.of.Contact, data = train_data)

# Make predictions on the test data
predictions <- predict(model, newdata = test_data)

# Evaluate the model
mse <- mean((test_data$Rent - predictions)^2)
rmse <- sqrt(mse)
r_squared <- 1 - (sum((test_data$Rent - predictions)^2) / sum((test_data$Rent - mean(test_data$Rent))^2))

# Print evaluation metrics
cat("Mean Squared Error:", mse, "\n")
cat("Root Mean Squared Error:", rmse, "\n")
cat("R-squared:", r_squared, "\n")
#_______________________________________________________________________________________________________
#Random Forest
# Load necessary packages
library(randomForest)

# Set a random seed for reproducibility
set.seed(456)

# Create a vector of random indices for training data
train_indices <- sample(1:nrow(HouseRent_Cleaned_Preprocessed), size = 0.7 * nrow(HouseRent_Cleaned_Preprocessed))

# Split the data
X_train <- HouseRent_Cleaned_Preprocessed[train_indices,]
y_train <- HouseRent_Cleaned_Preprocessed$Rent[train_indices]
X_test <- HouseRent_Cleaned_Preprocessed[-train_indices,]
y_test <- HouseRent_Cleaned_Preprocessed$Rent[-train_indices]


# Train the random forest model
rf_model <- randomForest(y_train ~ ., data = X_train)

# Make predictions
rf_prediction <- predict(rf_model, newdata = X_test)

# Calculate Mean Absolute Error (MAE)
mae_rf <- mean(abs(rf_prediction - y_test))

# Calculate Mean Squared Error (MSE)
mse_rf <- mean((rf_prediction - y_test)^2)

# Calculate Root Mean Squared Error (RMSE)
rmse_rf <- sqrt(mse_rf)

# Calculate R-squared
r_squared_rf <- 1 - sum((rf_prediction - y_test)^2) / sum((y_test - mean(y_test))^2)

# Print evaluation metrics
cat("Random Forest Model Evaluation:\n")
cat("Mean Absolute Error:", mae_rf, "\n")
cat("Mean Squared Error:", mse_rf, "\n")
cat("Root Mean Squared Error:", rmse_rf, "\n")
cat("R-squared:", r_squared_rf, "\n")

###################################################################################################
# Objective analysis question
# Question 1 How the distribution of Furnishing Status and Rent in each city?
# Plot the distribution of Furnishing Status in each city
ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status)) + 
  geom_bar(aes(fill = Furnishing.Status)) +
  scale_fill_manual(values = c("violet", "purple", "#800080")) +
  geom_text(stat = 'count', aes(label = ..count..), vjust = -0.5) +
  facet_wrap(~City) + 
  labs(title = "Distribution of Furnishing Status in Each City", 
       x = "Furnishing Status", 
       y = "Count") +
  theme_minimal()

# Plot the distribution of Rent in each city
ggplot(HouseRent_Cleaned, aes(x = Rent)) + 
  geom_histogram(binwidth = 5000, aes(fill = ..count..)) + 
  facet_wrap(~City) + 
  labs(title = "Distribution of Rent in Each City", 
       x = "Rent",
       y = "Count") +
  scale_x_continuous(breaks = seq(0, max(HouseRent_Cleaned$Rent), by = 50000)) +
  theme_minimal()

# Question 2 With different Furnishing status, what is the difference with the Rent price?
# Plotting the distribution of Rent based on Furnishing Status for each city
counts <- HouseRent_Cleaned %>% 
  group_by(City, Furnishing.Status) %>% 
  summarize(Count = n())

ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status, y = Rent, fill = Furnishing.Status)) + 
  geom_boxplot() +
  geom_text(data = counts, aes(label = Count, y = -Inf), vjust = -0.5, size = 3) +
  facet_wrap(~City) + 
  labs(title = "Distribution of Rent by Furnishing Status in Each City", 
       x = "Furnishing Status",
       y = "Rent") +
  theme_minimal() +
  theme(legend.position = "none")

ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status, y = Rent, fill = Furnishing.Status)) + 
  geom_jitter(width = 0.2, alpha = 0.6) +  # Create a jitter plot
  geom_text(data = counts, aes(label = Count, y = -Inf), vjust = -0.5, size = 3) +
  facet_wrap(~City) + 
  labs(title = "Distribution of Rent by Furnishing Status in Each City", 
       x = "Furnishing Status",
       y = "Rent") +
  theme_minimal() +
  theme(legend.position = "top")


ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status, y = Rent, fill = Furnishing.Status)) + 
  geom_jitter(alpha = 0.6, width = 0.1) +     # show individual data points
  geom_count(aes(size = ..n..), show.legend = FALSE) +   # show count of overlapping points
  facet_wrap(~City) + 
  labs(title = "Distribution of Rent by Furnishing Status in Each City", 
       y = "Rent", 
       x = "Furnishing Status") +
  theme_minimal() +
  theme(legend.position = "none")

# Queston 3 
# ANOVA test
anova_result <- aov(Rent ~ Furnishing.Status, data = HouseRent_Cleaned)
summary(anova_result)

# If ANOVA is significant, then perform Tukey HSD test for pairwise comparisons
if (summary(anova_result)[[1]][["Pr(>F)"]][1] < 0.05) {
  TukeyHSD(anova_result)
} else {
  print("No significant difference in Rent distribution based on Furnishing Status.")
}

# Average rent for each furnishing status across all cities
HouseRent_Cleaned %>%
  group_by(Furnishing.Status) %>%
  summarise(Average_Rent = mean(Rent, na.rm = TRUE))

avg_rent_by_status <- HouseRent_Cleaned %>%
  group_by(Furnishing.Status) %>%
  summarise(Average_Rent = mean(Rent, na.rm = TRUE))

# Bar chart
ggplot(avg_rent_by_status, aes(x = Furnishing.Status, y = Average_Rent, fill = Furnishing.Status)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("violet", "purple", "#800080")) +
  geom_text(aes(label = sprintf("%.0f", Average_Rent)), vjust = -0.5, size = 3.5) +
  labs(title = "Average Rent by Furnishing Status", 
       x = "Furnishing Status", 
       y = "Average Rent") +
  theme_minimal() +
  theme(legend.position = "none")

# City with the highest average rent for each furnished properties
HouseRent_Cleaned %>%
  filter(Furnishing.Status == "Furnished") %>%
  group_by(City) %>%
  summarise(Average_Rent = mean(Rent, na.rm = TRUE)) %>%
  arrange(desc(Average_Rent)) %>%
  head(1)

HouseRent_Cleaned %>%
  filter(Furnishing.Status == "Semi-Furnished") %>%
  group_by(City) %>%
  summarise(Average_Rent = mean(Rent, na.rm = TRUE)) %>%
  arrange(desc(Average_Rent)) %>%
  head(1)

HouseRent_Cleaned %>%
  filter(Furnishing.Status == "Unfurnished") %>%
  group_by(City) %>%
  summarise(Average_Rent = mean(Rent, na.rm = TRUE)) %>%
  arrange(desc(Average_Rent)) %>%
  head(1)


avg_rent_by_city_and_fstatus <- HouseRent_Cleaned %>%
  group_by(City, Furnishing.Status) %>%
  summarise(Average_Rent = mean(Rent, na.rm = TRUE))

# Bar chart
ggplot(avg_rent_by_city_and_fstatus, aes(x = City, y = Average_Rent, fill = Furnishing.Status)) +
  geom_bar(stat="identity", position="dodge") +
  scale_fill_manual(values = c("violet", "purple", "#800080")) +
  geom_text(aes(label=sprintf("%.0f", Average_Rent), y = Average_Rent + max(Average_Rent)*0.05), 
            position = position_dodge(width=0.9), vjust=-0.5, size=3.5) +
  labs(title = "Average Rent by City and Furnishing Status", 
       x = "City", 
       y = "Average Rent") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#  Difference in average rent between furnished and unfurnished properties in each city
library(tidyr)
avg_rent_difference <- HouseRent_Cleaned %>%
  filter(Furnishing.Status %in% c("Furnished", "Unfurnished")) %>%
  group_by(City, Furnishing.Status) %>%
  summarise(Average_Rent = mean(Rent, na.rm = TRUE)) %>%
  spread(Furnishing.Status, Average_Rent) %>%
  mutate(Difference = Furnished - Unfurnished)

# Bar chart for average rents
ggplot(avg_rent_difference, aes(x = City)) +
  geom_bar(aes(y = Furnished, fill = "Furnished"), stat="identity", position="dodge") +
  geom_bar(aes(y = Unfurnished, fill = "Unfurnished"), stat="identity", position="dodge") +
  geom_text(aes(y = Furnished, label=sprintf("%.0f", Furnished)), vjust=-0.5, position=position_dodge(width=0.9), size=3.5) +
  geom_text(aes(y = Unfurnished, label=sprintf("%.0f", Unfurnished)), vjust=-0.5, position=position_dodge(width=0.9), size=3.5) +
  labs(title = "Average Rent by City for Furnished vs. Unfurnished Properties", 
       x = "City", 
       y = "Average Rent") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_manual(values = c("Furnished" = "violet", "Unfurnished" = "purple"), name="Furnishing Status")

# Bar chart for difference in rents
ggplot(avg_rent_difference, aes(x = City, y = Difference, fill = City)) +
  geom_bar(stat="identity") +
  geom_text(aes(label=sprintf("%.0f", Difference)), vjust=-0.5, size=3.5) +
  labs(title = "Difference in Average Rent (Furnished - Unfurnished) by City", 
       x = "City", 
       y = "Difference in Average Rent") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
  legend.position = "none")

# Correlation between size and rent for each furnishing status
correlation_data <- HouseRent_Cleaned %>%
  group_by(Furnishing.Status) %>%
  summarise(Correlation = cor(Size, Rent, use = "complete.obs"))

# Bar chart
ggplot(correlation_data, aes(x = Furnishing.Status, y = Correlation, fill = Furnishing.Status)) +
  geom_bar(stat="identity", position="dodge") +
  scale_fill_manual(values = c("violet", "purple", "#800080")) +
  geom_text(aes(label=sprintf("%.3f", Correlation)), vjust=-0.5, size=3.5) +  
  labs(title = "Correlation between Size and Rent by Furnishing Status", 
       x = "Furnishing Status", 
       y = "Correlation Coefficient") +
  theme_minimal() +
  theme(legend.position = "none")

# Skewness of rent distribution for each furnishing status in each city 
install.packages("moments")
library("moments")
HouseRent_Cleaned %>%
  filter(City == "Bangalore") %>%
  group_by(Furnishing.Status) %>%
  summarise(Skewness = skewness(Rent, na.rm = TRUE))

HouseRent_Cleaned %>%
  filter(City == "Chennai") %>%
  group_by(Furnishing.Status) %>%
  summarise(Skewness = skewness(Rent, na.rm = TRUE))

HouseRent_Cleaned %>%
  filter(City == "Delhi") %>%
  group_by(Furnishing.Status) %>%
  summarise(Skewness = skewness(Rent, na.rm = TRUE))

HouseRent_Cleaned %>%
  filter(City == "Hyderabad") %>%
  group_by(Furnishing.Status) %>%
  summarise(Skewness = skewness(Rent, na.rm = TRUE))

HouseRent_Cleaned %>%
  filter(City == "Kolkata") %>%
  group_by(Furnishing.Status) %>%
  summarise(Skewness = skewness(Rent, na.rm = TRUE))

HouseRent_Cleaned %>%
  filter(City == "Mumbai") %>%
  group_by(Furnishing.Status) %>%
  summarise(Skewness = skewness(Rent, na.rm = TRUE))

# Can Furnishing Status predict Rent price in each city?
HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  do(anova(lm(Rent ~ Furnishing.Status, data = .)))


#Furnishing status, Rent, Area Type
ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status, y = Rent, fill = factor(Area.Type))) +
  geom_bar(stat = "identity", position = "dodge", color = "black") +
  facet_wrap(~City) +
  scale_fill_manual(name = "Area Type", values = c("#E6E6FA", "violet", "#800080")) +
  labs(title = "Rent Distribution by Furnishing Status and City", x = "Furnishing Status", y = "Rent")

#Furnishing status, Rent, BHK
ggplot(HouseRent_Cleaned, aes(x = factor(Furnishing.Status), y = Rent, fill = factor(BHK), color = factor(BHK))) +
  geom_point(alpha = 0.1) +
  scale_size_continuous(range = c(1, 12)) +
  facet_wrap(~City) +
  labs(title = "Rent Distribution by Furnishing Status and BHK", x = "Furnishing.Status", y = "Rent") 

#Furnishing status, Rent, size
ggplot(HouseRent_Cleaned, aes(x = Size, y = Rent, z = factor(Furnishing.Status), color = factor(Furnishing.Status))) + 
  geom_point(size = 3) +
  scale_color_manual(name = "Furnishing Status", values = c("violet", "purple", "#800080")) +
  labs(title = "Rent Distribution by Furnishing Status and City", x = "Size", y = "Rent") + 
  facet_wrap(~City)

#Furnishing status, Rent, Tenant Preferred
ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status, y = Rent, fill = Tenant.Preferred)) +
  geom_violin(scale = "width", trim = FALSE) +
  facet_wrap(~City) +
  scale_fill_manual(name = "Tenant Preferred", values = c("#E6E6FA", "violet", "#800080")) +
  labs(title = "Rent Distribution by Furnishing Status and City", x = "Furnishing Status", y = "Rent") +
  theme_minimal()

ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status, y = Rent, fill = factor(Tenant.Preferred))) +
  geom_bar(stat = "identity", position = "dodge", color = "black") +
  facet_wrap(~City) +
  scale_fill_manual(name = "Tenant Preferred", values = c("#E6E6FA", "violet", "#800080")) +
  labs(title = "Rent Distribution by Furnishing Status and Tenant Preferred", x = "Furnishing Status", y = "Rent") +
  theme_minimal()

#Furnishing status, Rent, Bathroom
ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status, y = Rent, fill = factor(Bathroom))) +
  geom_bar(stat = "identity", position = "dodge", color = "black") +
  facet_wrap(~City) +
  scale_fill_discrete(name = "Bathroom") + 
  labs(title = "Rent Distribution by Furnishing Status and Bathroom", x = "Furnishing Status", y = "Rent") +
  theme_minimal()

#Furnishing status, Rent, Point of Contact
ggplot(HouseRent_Cleaned, aes(x = Rent, fill = Point.of.Contact)) +
  geom_density(alpha = 0.5) +
  labs(title = "Rent Distribution by Furnishing Status and Point of Contact", x = "Rent", y = "Density") + 
  scale_fill_manual(name = "Point of Contact", values = c("#E6E6FA", "violet", "#800080")) +
  facet_wrap(~City) +
  theme_minimal()




