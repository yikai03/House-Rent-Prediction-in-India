# vector of package names
packages <- c("dplyr", "ggplot2", "GGally", "plotly", "corrplot", "ggthemes", "randomForest", "caret", "glmnet", "rpart", "rpart.plot")

# Install the packages
install.packages(packages)

library(dplyr)
library(ggplot2)
library(GGally)
library(plotly)
library(corrplot)
library(ggthemes)
library(randomForest)
library(caret)
library(glmnet)
library(rpart)
library(rpart.plot)


#Import dataset
HouseRent <- read.csv("C:/Users/willi/OneDrive/Degree/Y2S1/PFDA/Group Assignment/House_Rent_Dataset.csv")

#Show data in console
head(HouseRent,5)

# Show all Column name
names(HouseRent)

#Show data in table form
View(HouseRent)

#Show min, max, q1, q2, q3 and avg
summary(HouseRent$Rent)
summary(HouseRent$Size)
#_____________________________________________________________________________________________________________
#DATA CLEANING AND OUTLIER REPLACEMENT
#Check null value
colSums(is.na(HouseRent))

#Check duplicate row
sum(duplicated(HouseRent))

unique_cities = unique(HouseRent$City)

city_subsets = setNames(replicate(length(unique_cities), NULL), unique_cities)

for(i in unique_cities){
  city_subset = HouseRent %>% filter(City == i)
  city_subsets[[i]] = city_subset
}

city_subsets_unclean = city_subsets

#_______________________________________________________________________________________________________
#Cleaning part for rent
{#Cleaning for Kolkata Rent
max(city_subsets$Kolkata$Rent)
city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Rent !=180000, ]
city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Rent !=65000, ]
city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Rent !=60000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Kolkata$Rent)
boxplot(city_subsets$Kolkata$Rent)

head(city_subsets$Kolkata[order(city_subsets$Kolkata$Rent, decreasing = TRUE), ], 20)

#_______________________________________________________________________________________________________
#Cleaning for Mumbai Rent
max(city_subsets$Mumbai$Rent)
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=1200000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=1000000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=850000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=700000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=680000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=650000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=600000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=500000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=450000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Mumbai$Rent)
boxplot(city_subsets$Mumbai$Rent)

head(city_subsets$Mumbai[order(city_subsets$Mumbai$Rent, decreasing = TRUE), ], 10)

#_______________________________________________________________________________________________________
#Cleaning for Bangalore Rent
max(city_subsets$Bangalore$Rent)
city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=3500000, ]
city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=380000, ]
city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=280000, ]
city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=250000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Bangalore$Rent)
boxplot(city_subsets$Bangalore$Rent)

head(city_subsets$Bangalore[order(city_subsets$Bangalore$Rent, decreasing = TRUE), ], 10)

#_______________________________________________________________________________________________________
#Cleaning for Delhi Rent
max(city_subsets$Delhi$Rent)
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=530000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=350000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=280000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=260000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=250000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=200000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=190000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=150000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=140000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=130000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Delhi$Rent)
boxplot(city_subsets$Delhi$Rent)

head(city_subsets$Delhi[order(city_subsets$Delhi$Rent, decreasing = TRUE), ], 20)

#_______________________________________________________________________________________________________
#Cleaning for Chennai Rent
max(city_subsets$Chennai$Rent)
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=600000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=330000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=280000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=250000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=220000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=200000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Chennai$Rent)
boxplot(city_subsets$Chennai$Rent)

head(city_subsets$Chennai[order(city_subsets$Chennai$Rent, decreasing = TRUE), ], 20)

#_______________________________________________________________________________________________________
#Cleaning for Hyderabad Rent
max(city_subsets$Hyderabad$Rent)
city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=400000, ]
city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=300000, ]
city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=250000, ]
city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=200000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Hyderabad$Rent)
boxplot(city_subsets$Hyderabad$Rent)

head(city_subsets$Hyderabad[order(city_subsets$Hyderabad$Rent, decreasing = TRUE), ], 20)
}

#Cleaning part for Size
{#Cleaning for Kolkata Size
  max(city_subsets$Kolkata$Size)
  city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Size!=4000, ]
  city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Size!=3500, ]

  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Kolkata$Size)
  boxplot(city_subsets$Kolkata$Size)

  head(city_subsets$Kolkata[order(city_subsets$Kolkata$Size, decreasing = TRUE), ], 20)

  #_______________________________________________________________________________________________________
  #Cleaning for Mumbai Size
  max(city_subsets$Mumbai$Size)
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Size !=3700, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Size !=3250, ]

  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Mumbai$Size)
  boxplot(city_subsets$Mumbai$Size)

  head(city_subsets$Mumbai[order(city_subsets$Mumbai$Size, decreasing = TRUE), ], 10)

  #_______________________________________________________________________________________________________
  #Cleaning for Bangalore Size
  max(city_subsets$Bangalore$Size)

  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Bangalore$Size)
  boxplot(city_subsets$Bangalore$Size)

  head(city_subsets$Bangalore[order(city_subsets$Bangalore$Size, decreasing = TRUE), ], 10)

  #_______________________________________________________________________________________________________
  #Cleaning for Delhi Size
  max(city_subsets$Delhi$Size)

  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Delhi$Size)
  boxplot(city_subsets$Delhi$Size)

  head(city_subsets$Delhi[order(city_subsets$Delhi$Size, decreasing = TRUE), ], 20)

  #_______________________________________________________________________________________________________
  #Cleaning for Chennai Size
  max(city_subsets$Chennai$Size)
  city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Size !=6000, ]

  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Chennai$Size)
  boxplot(city_subsets$Chennai$Size)

  head(city_subsets$Chennai[order(city_subsets$Chennai$Size, decreasing = TRUE), ], 20)

  #_______________________________________________________________________________________________________
  #Cleaning for Hyderabad Size
  max(city_subsets$Hyderabad$Size)

  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Hyderabad$Size)
  boxplot(city_subsets$Hyderabad$Size)

  head(city_subsets$Hyderabad[order(city_subsets$Hyderabad$Size, decreasing = TRUE), ], 20)
}
#_______________________________________________________________________________________________________
#Comparison before cleaning and after cleaning
#Unclean distribution data of Rent in each city and BHK
custom_breaks <- seq(500000, max(HouseRent$Rent), by = 500000)

ggplot(HouseRent, aes(x = City, y = Rent, fill = factor(BHK))) +
  geom_bar(stat = "identity", position = "dodge", color="Black") +
  ggtitle("Rent Distribution by City and BHK") +
  labs(x = "City", y = "Rent") +
  scale_fill_discrete(name = "BHK") +
  scale_y_continuous(breaks = custom_breaks) +
  theme_minimal()

HouseRent_Cleaned = do.call(rbind, city_subsets)

ggplot(HouseRent_Cleaned, aes(x = City, y = Rent, fill = factor(BHK))) +
  geom_bar(stat = "identity", position = "dodge", color="Black") +
  ggtitle("Rent Distribution by City and BHK") +
  labs(x = "City", y = "Rent") +
  scale_fill_discrete(name = "BHK") +
  scale_y_continuous(breaks = custom_breaks) +
  theme_minimal()

View(HouseRent_Cleaned)

#SUMMARY AND VISUALISATION
# View data information
summary(HouseRent_Cleaned)
#_______________________________________________________________________________________________________
#Plotting anova results for each city
# Create a list of dataframes for each city
city_subsets <- split(HouseRent_Cleaned, HouseRent_Cleaned$City)

# Create a list of anova results for each city
city_anova <- lapply(city_subsets, function(x) {
  aov(Rent ~ Size, data = x)
})

# Create a list of anova summary for each city
city_anova_summary <- lapply(city_anova, summary)
city_anova_summary
# Convert data summary to a dataframe and bind columns together
summary_rent <- do.call(cbind, lapply(HouseRent_Cleaned, summary))
summary_rent <- as.data.frame(summary_rent)

# Select size and rent from summary_rent columns
select(summary_rent, c("Size", "Rent"))

#_______________________________________________________________________________________________________
#How does the relationship between size and rent vary across different cities, and what is the average rent per city?
# Scatter plot with regression lines for each city
size_rent_scatter <- ggplot(HouseRent_Cleaned, aes(x = Size, y = Rent, color = City)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Regression Analysis: Size vs. Rent across Different Cities", x = "Size (Square Feet)", y = "Rent (Rupees)")

# Convert ggplot to plotly object
size_rent_scatter <- ggplotly(size_rent_scatter)
size_rent_scatter

# Boxplot to visualize distribution of rent per city
rent_city_boxplot <- ggplot(HouseRent_Cleaned, aes(x = City, y = Rent, fill = City)) +
  geom_boxplot() +
  labs(title = "Boxplot: Distribution of Rent across Different Cities", x = "City", y = "Rent Amount")

rent_city_boxplot <- ggplotly(rent_city_boxplot)
rent_city_boxplot

# Calculate the average rent for each city
avg_rent_city <- HouseRent_Cleaned %>%
  group_by(City) %>%
  summarise(Avg_Rent = mean(Rent))

# Bar chart to show average rent per city
avg_rent_city_bar <- ggplot(avg_rent_city, aes(x = City, y = Avg_Rent, fill = City)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = round(Avg_Rent)), vjust = -0.5, size = 3.5) +
  labs(title = "Bar Chart: Average Rent per City", x = "City", y = "Average Rent Amount")

avg_rent_city_bar <- ggplotly(avg_rent_city_bar)
avg_rent_city_bar

#_______________________________________________________________________________________________________
#How does the relationship between size and rent vary across different BHKs, and what is the average rent per BHK?
# Scatter plot with regression lines for each BHK
size_rent_scatter <- ggplot(HouseRent_Cleaned, aes(x = Size, y = Rent, color = factor(BHK))) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Regression Analysis: Size vs. Rent across Different BHKs", x = "Size (Square Feet)", y = "Rent Amount")

# Convert ggplot to plotly object
size_rent_scatter <- ggplotly(size_rent_scatter)
size_rent_scatter

# Boxplot to visualise distribution of rent per Bdroom
rent_BHK_boxplot <- ggplot(HouseRent_Cleaned, aes(x = BHK, y = Rent, fill = factor(BHK))) +
  geom_boxplot() +
  labs(title = "Boxplot: Distribution of Rent across Different BHKs", x = "BHK", y = "Rent Amount")

rent_BHK_boxplot <- ggplotly(rent_BHK_boxplot)
rent_BHK_boxplot

# Calculate the averge rent for each BHK
avg_rent_BHK <- HouseRent_Cleaned %>%
  group_by(BHK) %>%
  summarise(Avg_Rent = mean(Rent))

# Bar chart to show average rent per BHK
avg_rent_BHK_bar <- ggplot(avg_rent_BHK, aes(x = BHK, y = Avg_Rent, fill = factor(BHK))) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = round(Avg_Rent)), vjust = -0.5, size = 3.5) +
  labs(title = "Bar Chart: Average Rent per BHK", x = "BHK", y = "Average Rent Amount")

avg_rent_BHK_bar <- ggplotly(avg_rent_BHK_bar)
avg_rent_BHK_bar

#_______________________________________________________________________________________________________
#How does the relationship between size and rent change with different area types (Super Area, Carpet Area, or Build Area)?
# Scatter plot with ara type as hue, faceted by area type
library(ggthemes)
area_type_scatter <- ggplot(HouseRent_Cleaned, aes(x = Size, y = Rent, color = Area.Type)) +
  geom_point(alpha = 0.7) +
  labs(title = "Scatter Plot: Relationship between Size and Rent by Area Type",
       x = "Size (Square Feet)", y = "Rent Amount", color = "Area Type") +
  facet_wrap(~ Area.Type, scales = "free") +
  theme_minimal() +
  theme(legend.position = "bottom", axis.text.x = element_text(angle = 90, hjust = 1)) +  # Rotate x-axis ticks
  scale_color_tableau()

plotly_area_type_scatter <- ggplotly(area_type_scatter)

plotly_area_type_scatter

# Boxplot with area type as hue
area_type_boxplot <- ggplot(HouseRent_Cleaned, aes(x = Area.Type, y = Rent, fill = Area.Type)) +
  geom_boxplot() +
  labs(title = "Boxplot: Distribution of Rent by Area Type", x = "Area Type", y = "Rent Amount") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  scale_fill_tableau()

ggplotly(area_type_boxplot)

# Calculate the average rent for each area type
avg_rent_area_type <- HouseRent_Cleaned %>%
  group_by(Area.Type) %>%
  summarise(Avg_Rent = mean(Rent))

# Bar chart show average rent per area type
avg_rent_area_type_bar <- ggplot(avg_rent_area_type, aes(x = Area.Type, y = Avg_Rent, fill = Area.Type)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = round(Avg_Rent)), vjust = -0.5, size = 3.5) +
  labs(title = "Bar Chart: Average Rent per Area Type", x = "Area Type", y = "Average Rent Amount")

avg_rent_area_type_bar <- ggplotly(avg_rent_area_type_bar)
avg_rent_area_type_bar

# Calculate the averge size for each area type
avg_size_area_type <- HouseRent_Cleaned %>%
  group_by(Area.Type) %>%
  summarise(Avg_Size = mean(Size))

# Create pie chart using plotly
avg_size_area_type_pie <- plot_ly(
  labels = avg_size_area_type$Area.Type,
  values = round(avg_size_area_type$Avg_Size),
  type = "pie",
  opacity = 0.7,
  marker = list(line = list(color = "#000000", width = 1)),
  textinfo = "label+percent+value",
  textposition = "inside",
  hole = 0.3
)

# Adding layout options
avg_size_area_type_pie <- avg_size_area_type_pie %>%
  layout(
    title = "Pie Chart: Average Size per Area Type",
    scene = list(
      aspectmode = "data",
      camera = list(
        eye = list(x = 1.5, y = 1.5, z = 1)
      )
    )
  )

# Show te pie chart
avg_size_area_type_pie

HouseRent_Cleaned$PricePerSquareFeet <- HouseRent_Cleaned$Rent / HouseRent_Cleaned$Size

#Calculate the average price per square feet for each area type
avg_price_per_square_feet_area_type <- HouseRent_Cleaned %>%
  group_by(Area.Type) %>%
  summarise(Avg_PricePerSquareFeet = mean(PricePerSquareFeet))

#pie to show average price per square feet per area type
avg_price_per_square_feet_area_type_pie <- ggplot(avg_price_per_square_feet_area_type, aes(x = "", y = Avg_PricePerSquareFeet, fill = Area.Type)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar("y", start = 0) +
  geom_text(aes(label = round(Avg_PricePerSquareFeet)), position = position_stack(vjust = 0.5), size = 3.5) +
  labs(title = "Pie Chart: Average Price per Square Feet per Area Type", x = "", y = "Average Price per Square Feet")

avg_price_per_square_feet_area_type_pie

#_______________________________________________________________________________________________________
#How does the relationship between size and rent change with different furnishing Status (Furnished, Semi-Furnished, or Unfurnished) for each city?
# Scatter plot with furnising status as hue, and is faceted by city
furnishing_type_scatter <- ggplot(HouseRent_Cleaned, aes(x = Size, y = Rent, color = Furnishing.Status)) +
  geom_point(alpha = 0.7) +
  labs(title = "Scatter Plot: Relationship between Size and Rent by Furnishing Status",
       x = "Size (Square Feet)", y = "Rent Amount", color = "Furnishing Status") +
  facet_wrap(~ City, scales = "free") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  scale_color_tableau()

ggplotly(furnishing_type_scatter)

# Boxplot with furnishing status as hue
furnishing_type_boxplot <- ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status, y = Rent, fill = Furnishing.Status)) +
  geom_boxplot() +
  labs(title = "Boxplot: Distribution of Rent by Furnishing Status", x = "Furnishing Status", y = "Rent Amount") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  scale_fill_tableau()

ggplotly(furnishing_type_boxplot)

# Calculate the average rent for each furnishing srtatus
avg_rent_furnishing_type <- HouseRent_Cleaned %>%
  group_by(Furnishing.Status) %>%
  summarise(Avg_Rent = mean(Rent))

# Bar chart to show average rent per furnishing type
avg_rent_furnishing_type_bar <- ggplot(avg_rent_furnishing_type, aes(x = Furnishing.Status, y = Avg_Rent, fill = Furnishing.Status)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = round(Avg_Rent)), vjust = -0.5, size = 3.5) +
  labs(title = "Bar Chart: Average Rent per Furnishing Status", x = "Furnishing Status", y = "Average Rent Amount")

avg_rent_furnishing_type_bar <- ggplotly(avg_rent_furnishing_type_bar)
avg_rent_furnishing_type_bar

# Calculate the average size for each furnishing type
avg_size_furnishing_type <- HouseRent_Cleaned %>%
  group_by(Furnishing.Status) %>%
  summarise(Avg_Size = mean(Size))

avg_size_furnishing_type_pie <- plot_ly(
  labels = avg_size_furnishing_type$Furnishing.Status,
  values = round(avg_size_furnishing_type$Avg_Size,2),
  type = "pie",
  opacity = 0.7,
  marker = list(line = list(color = "#000000", width = 1)),
  textinfo = "label+percent+value",
  textposition = "inside",
  hole = 0.3
)

# AddiNG layout options
avg_size_furnishing_type_pie <- avg_size_furnishing_type_pie %>%
  layout(
    title = "Pie Chart: Average Size per Furnishing Status",
    scene = list(
      aspectmode = "data",
      camera = list(
        eye = list(x = 1.5, y = 1.5, z = 1)
      )
    )
  )

avg_size_furnishing_type_pie

#_______________________________________________________________________________________________________
#How does the relationship between size and rent change with the number of bedrooms (BHK)?
# Investigate how the relationship betwen size and rent changes with the number of beds using violin plot
bedroom_size_rent_violin <- ggplot(HouseRent_Cleaned, aes(x = factor(BHK), y = Rent, fill = factor(BHK))) +
  geom_violin(alpha = 0.7) +
  labs(title = "Size & Rent by Number of Bedrooms",
       x = "Number of Bedrooms", y = "Rent (Rupees)") +
  theme_minimal()

ggplotly(bedroom_size_rent_violin)

#_______________________________________________________________________________________________________
#How does the relationship between size, rent, and the preferred tenant type (Tenant.Preferred) vary across different cities?
# Creating 3D scatter plot
scatter_3d <- plot_ly(data = HouseRent_Cleaned, x = ~Size, y = ~Rent, z = ~BHK,
                      color = ~Tenant.Preferred, colors = "Set1", marker = list(size = 5),
                      text = ~paste("Tenant:", Tenant.Preferred,
                                    "<br>BHK:", BHK,
                                    "<br>Size:", Size,
                                    "<br>Rent:", Rent),
                      type = "scatter3d", mode = "markers")

# Customise layout
scatter_3d <- scatter_3d %>% layout(
  title = "3D Scatter Plot: Size, Rent, BHK, and Tenant Preferred",
  scene = list(
    xaxis = list(title = "Size"),
    yaxis = list(title = "Rent"),
    zaxis = list(title = "BHK")
  )
)

# Display plot
scatter_3d

# Creating a parallel coordinates plot for relationship between size, rent, and preferred tenant type across different cities
parallel_coordinates_tenant <- ggpairs(HouseRent_Cleaned,
                                        columns = c("Size", "Rent", "Tenant.Preferred"),
                                        mapping = aes(color = City),
                                        title = "Parallel Coordinates Plot: Size, Rent, and Preferred Tenant Type by City")

parallel_coordinates_tenant <- ggplotly(parallel_coordinates_tenant)
parallel_coordinates_tenant

bubble_plot_bath <- ggplot(HouseRent_Cleaned, aes(x = Size, y = Rent, size = Bathroom, color = City)) +
  geom_point(alpha = 0.7) +
  labs(title = "Bubble Plot: Size, Rent, and Number of Bathrooms by City")

bubble_plot_bath <- ggplotly(bubble_plot_bath)
bubble_plot_bath

bubble_plot_tennant <- ggplot(HouseRent_Cleaned, aes(x = Size, y = Rent, size = BHK, color = Tenant.Preferred)) +
  geom_point(alpha = 0.7) +
  labs(title = "Bubble Plot: Size, Rent, and Number of Bedrooms by Tenant Preferred")

bubble_plot_tennant <- ggplotly(bubble_plot_tennant)
bubble_plot_tennant

tenant_city_bar <- ggplot(HouseRent_Cleaned, aes (x = City, fill = Tenant.Preferred)) + geom_bar() +
  labs(title = "Bar Chart: Distribution of Preferred Tenant Types by City", x = "City",  y = "Count") +
  theme_minimal() + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_brewer(palette = "Set2")

ggplotly(tenant_city_bar)

#_______________________________________________________________________________________________________
# How does the relationship between size and rent vary based on the number of bedrooms?
# Scatter plot to visualis the relationship between size and rent by number of bedrooms
bedroom_size_rent_scatter <- ggplot(HouseRent_Cleaned, aes(x = Size, y = Rent, color = factor(BHK))) +
  geom_point(alpha = 0.7) +
  labs(title = "Scatter Plot: Relationship between Size and Rent by Number of Bedrooms",
       x = "Size (Square Feet)", y = "Rent (Rupees)") +
  theme_minimal() +
  theme(legend.position = "bottom")

bedroom_size_rent_scatter <- ggplotly(bedroom_size_rent_scatter)
bedroom_size_rent_scatter

parallel_coordinates_plot_BHK <- ggpairs(HouseRent_Cleaned,
                                      columns = c("Size", "Rent", "BHK"),
                                      mapping = aes(color = City),
                                      title = "Parallel Coordinates Plot: Size, Rent, and Bebrooms by City")

parallel_coordinates_plot_BHK <- ggplotly(parallel_coordinates_plot_BHK)
parallel_coordinates_plot_BHK


#_______________________________________________________________________________________________________
#How do the relationships between size, rent, and number of bathrooms vary across different cities?
# 3D scatter plot with area type
scatter_3d_bathrooms <- plot_ly(HouseRent_Cleaned, x = ~Size, y = ~Rent, z = ~Bathroom,
                                color = ~City, marker = list(size = 3)) %>%
  add_markers() %>%
  layout(scene = list(xaxis = list(title = "Size"),
                      yaxis = list(title = "Rent"),
                      zaxis = list(title = "Number of Bathrooms")),
         title = "3D Scatter Plot: Size, Rent, BHK, and Number of Bathrooms")

scatter_3d_bathrooms

#Parallel Coordinates Plot
# Create a paralel coordinates plot for relationship between size, rent, and number of bathrooms acros different cities
parallel_coordinates_bathroom <- ggpairs(HouseRent_Cleaned,
                                      columns = c("Size", "Rent", "Bathroom"),
                                      mapping = aes(color = City),
                                      title = "Parallel Coordinates Plot: Size, Rent, and Bathroom by City")

parallel_coordinates_bathroom <- ggplotly(parallel_coordinates_bathroom )
parallel_coordinates_bathroom




#_______________________________________________________________________________________________________
#How does the relationship between size and rent change with different area types?
# Scatter plot to visualise the relationship between size and rent by area type
area_type_size_rent_scatter <- ggplot(HouseRent_Cleaned, aes(x = Size, y = Rent, color = Area.Type)) +
  geom_point(alpha = 0.7) +
  labs(title = "Scatter Plot: Relationship between Size and Rent by Area Type",
       x = "Size (Square Feet)", y = "Rent (Rupees)") +
  facet_wrap(~ Area.Type, scales = "free") +
  theme_minimal() +
  theme(legend.position = "bottom")

area_type_size_rent_scatter <- ggplotly(area_type_size_rent_scatter)
area_type_size_rent_scatter

#_______________________________________________________________________________________________________
#Is there any correlation between the number of bathrooms and the size of the house, and how does this correlation vary across different cities?
# Calculate the correlation between the number of bathrooms and the size of the house
correlation_bath_size <- cor(HouseRent_Cleaned$Bathroom, HouseRent_Cleaned$Size)

# Display the correlation
cat("Correlation between Number of Bathrooms and Size:", correlation_bath_size)

# Calculate the correlation between number of bathrooms and size for each city using dplyr
correlation_bath_size_city <- HouseRent_Cleaned %>%
  group_by(City) %>%
  summarise(Correlation = cor(Bathroom, Size))

# bar chart to visualise the correlation between number of bathrooms and size per city
correlation_bath_size_city_bar <- ggplot(correlation_bath_size_city, aes(x = reorder(City, Correlation), y = Correlation, fill = City)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = round(Correlation, 2)), vjust = -0.5, size = 3.5) +
  labs(title = "Bar Chart: Correlation between Number of Bathrooms and Size per City",
       x = "City", y = "Correlation") +
  theme_minimal()

correlation_bath_size_city_bar <- ggplotly(correlation_bath_size_city_bar)
correlation_bath_size_city_bar

#_______________________________________________________________________________________________________
# What is the distribution of preferred tenant types across different cities?
# bar chart to show the distribution of preferred tenant types across cities
tenant_city_bar <- ggplot(HouseRent_Cleaned, aes(x = City, fill = Tenant.Preferred)) +
  geom_bar() +
  labs(title = "Bar Chart: Distribution of Preferred Tenant Types by City",
       x = "City", y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_brewer(palette = "Set2")

tenant_city_bar <- ggplotly(tenant_city_bar)
tenant_city_bar

#_______________________________________________________________________________________________________
# How does the furnishing status of properties relate to their rent amounts?
# boxplot to compare rent amounts acrss different furnishing statuses
boxplot_furnishing_rent <- ggplot(HouseRent_Cleaned, aes(x = Furnishing.Status, y = Rent, fill = Furnishing.Status)) +
  geom_boxplot() +
  labs(title = "Boxplot: Rent Amounts based on Furnishing Status",
       x = "Furnishing Status", y = "Rent Amount") +
  theme_minimal() +
  theme(legend.position = "bottom")

boxplot_furnishing_rent <- ggplotly(boxplot_furnishing_rent)
boxplot_furnishing_rent

#_______________________________________________________________________________________________________
#Is there a significant correlation between the size of the house and the rent amount, and does this correlation differ among different cities?
# Calculate the correlation between size and rent overall
correlation_size_rent <- cor(HouseRent_Cleaned$Size, HouseRent_Cleaned$Rent)

# Prin overall correlation
cat("Correlation between Size and Rent:", correlation_size_rent, "\n")

# Calculate the correlation between size and rent for each city
correlation_size_rent_city <- HouseRent_Cleaned %>%
  group_by(City) %>%
  summarise(Correlation = cor(Size, Rent))

# Print the correlation for each city
for (i in seq_len(nrow(correlation_size_rent_city))) {
  cat("Correlation between Size and Rent for", correlation_size_rent_city$City[i], ":", correlation_size_rent_city$Correlation[i], "\n")
}

#  chart to visualise the correlations per city
correlation_size_rent_city_bar <- ggplot(correlation_size_rent_city, aes(x = reorder(City, Correlation), y = Correlation, fill = City)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = round(Correlation, 2)), vjust = -0.5, size = 3.5) +
  labs(title = "Bar Chart: Correlation between Size and Rent per City", x = "City", y = "Correlation")

correlation_size_rent_city_bar <- ggplotly(correlation_size_rent_city_bar)
correlation_size_rent_city_bar

#_______________________________________________________________________________________________________
#What is the average price per square feet for each city?
# Calculate the avg price per sq feet for each city
avg_price_per_square_feet_city <- HouseRent_Cleaned %>%
  group_by(City) %>%
  summarise(Avg_PricePerSquareFeet = mean(Rent / Size))  # PricePerSquareFeet calculation

# Plot bar
avg_price_per_square_feet_city_bar <- ggplot(avg_price_per_square_feet_city, aes(x = City, y = Avg_PricePerSquareFeet, fill = City)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = round(Avg_PricePerSquareFeet)), vjust = -0.5, size = 3.5) +
  labs(title = "Bar Chart: Average Price per Square Foot per City", x = "City", y = "Average Price per Square Foot")

avg_price_per_square_feet_city_bar <- ggplotly(avg_price_per_square_feet_city_bar)
avg_price_per_square_feet_city_bar

#_______________________________________________________________________________________________________
#What is the distribution of house sizes across different cities?
# Distribution of house sizes across different cities
size_city_boxplot <- ggplot(HouseRent_Cleaned, aes(x = City, y = Size, fill = City)) +
  geom_boxplot() +
  labs(title = "Boxplot: Distribution of Size across Different Cities", x = "City", y = "Size (Square Feet)")

size_city_boxplot <- ggplotly(size_city_boxplot)
size_city_boxplot

#_______________________________________________________________________________________________________
#How does the relationship between size categories (small, medium, large), rent, and price per square feet vary across different cities?
# Create size categories (small, medium, large) based on sq. footage
HouseRent_Cleaned$Size_Category <- ifelse(HouseRent_Cleaned$Size < 500, "Small",
                                          ifelse(HouseRent_Cleaned$Size >= 500 & HouseRent_Cleaned$Size < 1000, "Medium", "Large"))
# Calculate the average rent for each size category
avg_rent_size_category <- HouseRent_Cleaned %>%
  group_by(Size_Category) %>%
  summarise(Avg_Rent = mean(Rent))
# Calculate the average price per square fet for each size category
avg_price_per_square_feet_size_category <- HouseRent_Cleaned %>%
  group_by(Size_Category) %>%
  summarise(Avg_PricePerSquareFeet = mean(PricePerSquareFeet))
# Scatter plot visulises the relationship between size category and rent
size_category_rent_scatter <- ggplot(HouseRent_Cleaned, aes(x = Size_Category, y = Rent, color = Size_Category)) +
  geom_point(alpha = 0.7) +
  labs(title = "Scatter Plot: Relationship between Size Category and Rent",
       x = "Size Category", y = "Rent (Rupepes)") +
  facet_wrap(~ Size_Category, scales = "free") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  scale_color_tableau()
ggplotly(size_category_rent_scatter)
# Scatter plot to visualise the relationship between size category and price per square feet
size_category_price_per_square_feet_scatter <- ggplot(HouseRent_Cleaned, aes(x = Size_Category, y = PricePerSquareFeet, color = Size_Category)) +
  geom_point(alpha = 0.7) +
  labs(title = "Scatter Plot: Relationship between Size Category and Price per Square Feet",
       x = "Size Category", y = "Price per Square Feet") +
  facet_wrap(~ Size_Category, scales = "free") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  scale_color_tableau()
ggplotly(size_category_price_per_square_feet_scatter)


# Cluster the data based on size and rent
HouseRent_Cleaned_Cluster <- HouseRent_Cleaned %>%
  select(Size, Rent)

# Scale the data
HouseRent_Cleaned_Cluster_Scaled <- scale(HouseRent_Cleaned_Cluster)

# Cluster the data into 3 clusters
HouseRent_Cleaned_Cluster_KMeans <- kmeans(HouseRent_Cleaned_Cluster_Scaled, 2, nstart = 10, iter.max = 1000)

# Add the cluster labels to the data
HouseRent_Cleaned_Cluster <- HouseRent_Cleaned_Cluster %>%
  mutate(Cluster = as.factor(HouseRent_Cleaned_Cluster_KMeans$cluster))

# Scatter plot to visualize the relationship between size and rent
size_rent_scatter <- ggplot(HouseRent_Cleaned_Cluster, aes(x = Size, y = Rent, color = Cluster)) +
  geom_point(alpha = 0.7) +
  labs(title = "Scatter Plot: Relationship between Size and Rent",
       x = "Size (Square Feet)", y = "Rent)") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  scale_color_discrete()

size_rent_scatter <- ggplotly(size_rent_scatter)
size_rent_scatter

library(ggthemes)
library(dplyr)
#Bar plots to see avg price per square foot for each small, medium and large category across cities.
# Calculate the average price per square foot for each size category across cities

# Create size categories (small, medium, large) based on square footage
HouseRent_Cleaned$Size_Category <- ifelse(HouseRent_Cleaned$Size < 500, "Small",
                                          ifelse(HouseRent_Cleaned$Size >= 500 & HouseRent_Cleaned$Size < 1000, "Medium", "Large"))

avg_price_per_square_feet_size_category_city <- HouseRent_Cleaned %>%
  group_by(Size_Category, City) %>%
  summarise(Avg_PricePerSquareFeet = mean(PricePerSquareFeet))

# Plot the average price per square foot for each size category across cities in a bar chart
avg_price_per_square_feet_size_category_city_bar <- ggplot(avg_price_per_square_feet_size_category_city, aes(x = City, y = Avg_PricePerSquareFeet, fill = City)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = round(Avg_PricePerSquareFeet)), vjust = -0.5, size = 3.5) +
  labs(title = "Bar Chart: Average Price per Square Feet for each Size Category across Cities", x = "City", y = "Average Price per Square Feet") +
  facet_wrap(~ Size_Category, scales = "free") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  scale_fill_tableau()

avg_price_per_square_feet_size_category_city_bar <- ggplotly(avg_price_per_square_feet_size_category_city_bar)
avg_price_per_square_feet_size_category_city_bar

#--------------------------------------------------------------------------------------------------------------#
#DEVELOPING MODELS
#Data Pre-processing for corr
HouseRent_Cleaned_Preprocessed = HouseRent_Cleaned

HouseRent_Cleaned_Preprocessed <- HouseRent_Cleaned_Preprocessed %>%
  mutate(Area.Type = case_when(
    Area.Type == "Super Area" ~ 0,
    Area.Type == "Carpet Area" ~ 1,
    Area.Type == "Built Area" ~ 2
  ),
  Furnishing.Status = case_when(
    Furnishing.Status == "Unfurnished" ~ 0,
    Furnishing.Status == "Semi-Furnished" ~ 1,
    Furnishing.Status == "Furnished" ~ 2
  ),
  Point.of.Contact = case_when(
    Point.of.Contact == "Contact Owner" ~ 0,
    Point.of.Contact == "Contact Agent" ~ 1,
    Point.of.Contact == "Contact Builder" ~ 2
  ),
  Tenant.Preferred = case_when(
    Tenant.Preferred == "Family" ~ 0,
    Tenant.Preferred == "Bachelors" ~ 1,
    Tenant.Preferred == "Bachelors/Family" ~ 2
  ))

HouseRent_Cleaned_Preprocessed <- select(HouseRent_Cleaned_Preprocessed, -Posted.On, -Floor, -Area.Locality)
View(HouseRent_Cleaned_Preprocessed)

city_subsets_preprocessed <- setNames(replicate(length(unique_cities), NULL), unique_cities)

for(i in unique_cities){
  city_subset_preprocessed = HouseRent_Cleaned_Preprocessed %>% filter(City == i)
  city_subsets_preprocessed[[i]] = city_subset_preprocessed
}




# Split the data into training and testing sets
train_index <- sample(seq_len(nrow(HouseRent_Cleaned_Preprocessed)), 0.7 * nrow(HouseRent_Cleaned_Preprocessed))
train_data <- HouseRent_Cleaned_Preprocessed[train_index, ]
test_data <- HouseRent_Cleaned_Preprocessed[-train_index, ]

# Fit the linear regression model
lm_model <- lm(Rent ~ ., data = train_data)

# Model summary
summary(lm_model)

# Extract residuals from the model
residuals <- resid(lm_model)

# Create a plot of residuals
plot(predict(lm_model), residuals,
     xlab = "Fitted values",
     ylab = "Residuals",
     main = "Residual Plot Linear Regression Model")
abline(h = 0, col = "red")  # Add a horizontal line at y = 0

# Predict on the test set
lm_predictions <- predict(lm_model, newdata = test_data)

# Evaluate the model
lm_rmse <- sqrt(mean((lm_predictions - test_data$Rent)^2))
lm_rmse

#----------------------------------------------------------------------------------------------------#

# Create a vector of random indices for training data
train_indices <- sample(1:nrow(HouseRent_Cleaned_Preprocessed), size = 0.7 * nrow(HouseRent_Cleaned_Preprocessed))

# Split data
X_train <- HouseRent_Cleaned_Preprocessed[train_indices,]
y_train <- HouseRent_Cleaned_Preprocessed$Rent[train_indices]
X_test <- HouseRent_Cleaned_Preprocessed[-train_indices,]
y_test <- HouseRent_Cleaned_Preprocessed$Rent[-train_indices]
# Trai random forest model
rf_model <- randomForest(y_train ~ ., data = X_train)
summary(rf_model)

# Make predictions
rf_prediction <- predict(rf_model, newdata = X_test)

rf_residuals <- y_test - rf_prediction

# Create a plot of residuals
plot(rf_prediction, rf_residuals,
     xlab = "Predicted values",
     ylab = "Residuals",
     main = "Residual Plot for Random Forest")
abline(h = 0, col = "red")  # Add a horizontal line at y = 0
# Calculate Mean Absolute Error (MAE)
mae_rf <- mean(abs(rf_prediction - y_test))

# Calculate Mean Squared Error (MSE)
mse_rf <- mean((rf_prediction - y_test)^2)

# Calculate Root Mean Squared Error (RMSE)
rmse_rf <- sqrt(mse_rf)

# Calculate R-squared
r_squared_rf <- 1 - sum((rf_prediction - y_test)^2) / sum((y_test - mean(y_test))^2)

# Print evaluation metrics
cat("Random Forest Model Evaluation:\n")
cat("Mean Absolute Error:", mae_rf, "\n")
cat("Mean Squared Error:", mse_rf, "\n")
cat("Root Mean Squared Error:", rmse_rf, "\n")
cat("R-squared:", r_squared_rf, "\n")

# Data frame with actual and predicted values
actual_vs_predicted <- data.frame(Actual = y_test, Predicted = rf_prediction)

# Create a scatter plot
plot <- ggplot(actual_vs_predicted, aes(x = Actual, y = Predicted)) +
  geom_point() +
  geom_abline(intercept = 0, slope = 1, color = "red", linetype = "dashed") +  # Add a reference line
  labs(title = "Actual vs. Predicted Rent (Random Forest)",
       x = "Actual Rent",
       y = "Predicted Rent") +
  theme_minimal()

p <- ggplotly(plot)
p


# Get feature importance scores
feature_importance <- importance(rf_model)

# Convert feature importance scores to a data frame for easier manpulation
feature_importance_df <- data.frame(Feature = rownames(feature_importance), Importance = rowMeans(feature_importance))

# Exclude the "Rent" column from the dataframe
feature_importance_df <- feature_importance_df[feature_importance_df$Feature != "Rent", ]

# Define a palette of 8 colors
color_palette <- c("blue", "green", "orange", "purple", "red", "pink", "cyan", "yellow")

plot_fImportance <- plot_ly(data = feature_importance_df, x = ~Importance, y = ~Feature, type = "bar", orientation = 'h',
                            marker = list(color = color_palette),
                            text = ~paste("Importance: ", round(Importance, 2))) %>%
  layout(title = "Feature Importance for Predicting Rent",
         xaxis = list(title = "Importance"),
         yaxis = list(title = "Feature"),
         showlegend = FALSE)

# Show the plot
plot_fImportance

write.csv(HouseRent_Cleaned_Preprocessed, "C:\\Users\\willi\\OneDrive - Asia Pacific University\\Degree\\Y2S1\\PFDA\\Group Assignment\\data.csv", row.names=FALSE)
#------------------------------------------------------------------------------------------------------------------------#

# Fitting a decision tree model to predict Rent based on other features
tree_model <- rpart(Rent ~ ., data = train_data, method = "anova")

# Plot decision tree
rpart.plot(tree_model, box.palette = "RdBu", shadow.col = "gray", nn = TRUE)

# Make predictions
tree_prediction <- predict(tree_model, newdata = test_data)

# Calculate Mean Absolute Error (MAE)
mae_tree <- mean(abs(tree_prediction - test_data$Rent))

# Calculate Mean Squared Error (MSE)
mse_tree <- mean((tree_prediction - test_data$Rent)^2)

# Calculate Root Mean Squared Error (RMSE)
rmse_tree <- sqrt(mse_tree)

# Calculate R-squared
r_squared_tree <- 1 - sum((tree_prediction - test_data$Rent)^2) / sum((test_data$Rent - mean(test_data$Rent))^2)


# Print evaluation metrics
cat("Decision Tree Model Evaluation:\n")
cat("Mean Absolute Error:", mae_tree, "\n")
cat("Mean Squared Error:", mse_tree, "\n")
cat("Root Mean Squared Error:", rmse_tree, "\n")
cat("R-squared:", r_squared_tree, "\n")

# Create a data frame with actual and predicted values
actual_vs_predicted <- data.frame(Actual = test_data$Rent, Predicted = tree_prediction)

# Create a scatter plot
plot <- ggplot(actual_vs_predicted, aes(x = Actual, y = Predicted)) +
  geom_point() +
  geom_abline(intercept = 0, slope = 1, color = "red", linetype = "dashed") +  # Add a reference line
  labs(title = "Actual vs. Predicted Rent (Decision Tree)",
       x = "Actual Rent",
       y = "Predicted Rent") +
  theme_minimal()

p_dt <- ggplotly(plot)
p_dt

#----------------------------------------------------------------------------------------------------#
# Perform ANOVA testing
anova_result <- aov(Rent ~ ., data = HouseRent_Cleaned_Preprocessed)

# Summarize ANOVA results
summary(anova_result)

# Extract F-statistics and p-values for each predictor variable
f_statistics <- anova_result$"F value"
p_values <- anova_result$"Pr(>F)"

hist(anova_result$residuals)

qqPlot(anova_result$residuals,
       id = FALSE # id = FALSE to remove point identification
)


#-------------------------------------------------------------------------------------------------#
# Update the "City" column using label encoding
HouseRent_Cleaned_Preprocessed <- HouseRent_Cleaned_Preprocessed %>%
  mutate(City = case_when(
    City == "Kolkata" ~ 0,
    City == "Mumbai" ~ 1,
    City == "Bangalore" ~ 2,
    City == "Delhi" ~ 3,
    City == "Chennai" ~ 4,
    City == "Hyderabad" ~ 5
    # Add more city mappings if needed
  ))
columns <- c("BHK", "Rent", "Size", "Area.Type", "City",
             "Furnishing.Status", "Tenant.Preferred", "Bathroom", "Point.of.Contact")

# Extract the selected columns from the dataset
selected_data <- HouseRent_Cleaned_Preprocessed[columns]

# Compute the correlation matrix
correlation_matrix <- cor(selected_data)

colour_palette <- c("white","#9FD0F9","#53A0D8","#2671B2","#F7A56F", "#F15A24", "#A73D10")

# Correlation plot witH corrplot
corrplot(correlation_matrix, method = "pie", tl.col = "black", tl.cex = 0.7, col = colour_palette,
         addCoef.col = "black", # Color of correlation coefficient text
         order = "hclust",     # Order rows and columns using hierarchical clustering
         cl.pos = "n")         # Position of cluster labels (none)


feature_importance
