#Install packages
install.packages("readxl")
install.packages("dplyr")
install.packages("ggplot2")
install.packages("GGally")
install.packages("plotly")
install.packages("corrplot")
#Use packages
library(dplyr)
library(ggplot2)
library(GGally)
library(plotly)
library(corrplot)
library(randomForest)


#Import dataset
HouseRent = read.csv("C:\\Users\\YC PUAH\\OneDrive - Asia Pacific University\\L2S1\\PFDA\\Assignment\\House_Rent_Dataset.csv", header = TRUE)

#Show data in console
HouseRent

# Show all Column name
names(HouseRent) 

#Show data in table form
View(HouseRent)

#Total column 
ncol(HouseRent)

#Total row
nrow(HouseRent)

#Structure of the dataset
str(HouseRent)

#Show min, max, q1, q2, q3 and avg
summary(HouseRent$Rent)
summary(HouseRent$Size)
#_____________________________________________________________________________________________________________
#DATA CLEANING AND OUTLIER REPLACEMENT
#Check null value
colSums(is.na(HouseRent))

#Check duplicate row
sum(duplicated(HouseRent))

#Check for outlier
boxplot(HouseRent$Rent)
title("Boxplot for Rent Price")
boxplot(HouseRent$Size)
title("Boxplot for Size")

unique_cities = unique(HouseRent$City)

city_subsets <- setNames(replicate(length(unique_cities), NULL), unique_cities)

for(i in unique_cities){
  city_subset = HouseRent %>% filter(City == i)
  city_subsets[[i]] = city_subset
}

city_subsets_unclean = city_subsets

#_______________________________________________________________________________________________________
#Cleaning part for rent
{#Cleaning for Kolkata Rent
max(city_subsets$Kolkata$Rent)
city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Rent !=180000, ]
city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Rent !=65000, ]
city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Rent !=60000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Kolkata$Rent)
title("Before Cleaning")
boxplot(city_subsets$Kolkata$Rent)
title("After Cleaning")

head(city_subsets$Kolkata[order(city_subsets$Kolkata$Rent, decreasing = TRUE), ], 20)

#_______________________________________________________________________________________________________
#Cleaning for Mumbai Rent
max(city_subsets$Mumbai$Rent)
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=1200000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=1000000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=850000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=700000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=680000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=650000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=600000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=500000, ]
city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Rent !=450000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Mumbai$Rent)
title("Before Cleaning")
boxplot(city_subsets$Mumbai$Rent)
title("After Cleaning")

head(city_subsets$Mumbai[order(city_subsets$Mumbai$Rent, decreasing = TRUE), ], 20)

#_______________________________________________________________________________________________________
#Cleaning for Bangalore Rent
max(city_subsets$Bangalore$Rent)
city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=3500000, ]
city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=380000, ]
city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=280000, ]
city_subsets$Bangalore = city_subsets$Bangalore[city_subsets$Bangalore$Rent !=250000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Bangalore$Rent)
title("Before Cleaning")
boxplot(city_subsets$Bangalore$Rent)
title("After Cleaning")

head(city_subsets$Bangalore[order(city_subsets$Bangalore$Rent, decreasing = TRUE), ], 20)

#_______________________________________________________________________________________________________
#Cleaning for Delhi Rent
max(city_subsets$Delhi$Rent)
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=530000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=350000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=280000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=260000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=250000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=200000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=190000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=150000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=140000, ]
city_subsets$Delhi = city_subsets$Delhi[city_subsets$Delhi$Rent !=130000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Delhi$Rent)
title("Before Cleaning")
boxplot(city_subsets$Delhi$Rent)
title("After Cleaning")

head(city_subsets$Delhi[order(city_subsets$Delhi$Rent, decreasing = TRUE), ], 20)

#_______________________________________________________________________________________________________
#Cleaning for Chennai Rent
max(city_subsets$Chennai$Rent)
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=600000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=330000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=280000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=250000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=220000, ]
city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Rent !=200000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Chennai$Rent)
title("Before Cleaning")
boxplot(city_subsets$Chennai$Rent)
title("After Cleaning")

head(city_subsets$Chennai[order(city_subsets$Chennai$Rent, decreasing = TRUE), ], 20)

#_______________________________________________________________________________________________________
#Cleaning for Hyderabad Rent
max(city_subsets$Hyderabad$Rent)
city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=400000, ]
city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=300000, ]
city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=250000, ]
city_subsets$Hyderabad = city_subsets$Hyderabad[city_subsets$Hyderabad$Rent !=200000, ]

#Comparison before and after cleaning
boxplot(city_subsets_unclean$Hyderabad$Rent)
title("Before Cleaning")
boxplot(city_subsets$Hyderabad$Rent)


head(city_subsets$Hyderabad[order(city_subsets$Hyderabad$Rent, decreasing = TRUE), ], 20)
} 

#Cleaning part for Size
{#Cleaning for Kolkata Size
  max(city_subsets$Kolkata$Size)
  city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Size!=4000, ]
  city_subsets$Kolkata = city_subsets$Kolkata[city_subsets$Kolkata$Size!=3500, ]

  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Kolkata$Size)
  title("Before Cleaning")
  boxplot(city_subsets$Kolkata$Size)
  title("After Cleaning")
  
  head(city_subsets$Kolkata[order(city_subsets$Kolkata$Size, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Mumbai Size
  max(city_subsets$Mumbai$Size)
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Size !=3700, ]
  city_subsets$Mumbai = city_subsets$Mumbai[city_subsets$Mumbai$Size !=3250, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Mumbai$Size)
  title("Before Cleaning")
  boxplot(city_subsets$Mumbai$Size)
  title("After Cleaning")
  
  head(city_subsets$Mumbai[order(city_subsets$Mumbai$Size, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Bangalore Size
  max(city_subsets$Bangalore$Size)
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Bangalore$Size)
  title("Size boxplot in Bangalore")
  boxplot(city_subsets$Bangalore$Size)
  title("Size boxplot in Bangalore")
  
  head(city_subsets$Bangalore[order(city_subsets$Bangalore$Size, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Delhi Size
  max(city_subsets$Delhi$Size)
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Delhi$Size)
  title("Size boxplot in Delhi")
  boxplot(city_subsets$Delhi$Size)
  title("Size boxplot in Delhi")
  
  head(city_subsets$Delhi[order(city_subsets$Delhi$Size, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Chennai Size
  max(city_subsets$Chennai$Size)
  city_subsets$Chennai = city_subsets$Chennai[city_subsets$Chennai$Size !=6000, ]
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Chennai$Size)
  title("Before Cleaning")
  boxplot(city_subsets$Chennai$Size)
  title("After Cleaning")
  
  head(city_subsets$Chennai[order(city_subsets$Chennai$Size, decreasing = TRUE), ], 20)
  
  #_______________________________________________________________________________________________________
  #Cleaning for Hyderabad Size
  max(city_subsets$Hyderabad$Size)
  
  #Comparison before and after cleaning
  boxplot(city_subsets_unclean$Hyderabad$Size)
  title("Size boxplot in Hydarabad")
  boxplot(city_subsets$Hyderabad$Size)
  title("Size boxplot in Hyderabad")
  
  head(city_subsets$Hyderabad[order(city_subsets$Hyderabad$Size, decreasing = TRUE), ], 20)
} 
#_______________________________________________________________________________________________________
#Comparison before cleaning and after cleaning
custom_breaks <- seq(500000, max(HouseRent$Rent), by = 500000)

ggplot(HouseRent, aes(x = City, y = Rent)) +
  geom_bar(stat = "identity", position = "dodge") +
  ggtitle("Rent Distribution by City before cleaning") +
  labs(x = "City", y = "Rent") +
  scale_y_continuous(breaks = custom_breaks) +
  theme_minimal()

ggplot(HouseRent, aes(x = City, y = Size)) +
  geom_bar(stat = "identity", position = "dodge") +
  ggtitle("Size Distribution by City before cleaning") +
  labs(x = "City", y = "Size") +
  theme_minimal()

HouseRent_Cleaned = do.call(rbind, city_subsets)

ggplot(HouseRent_Cleaned, aes(x = City, y = Rent)) +
  geom_bar(stat = "identity", position = "dodge") +
  ggtitle("Rent Distribution by City after cleaning") +
  labs(x = "City", y = "Rent") +
  scale_y_continuous(breaks = (seq(100000, max(HouseRent_Cleaned$Rent), by = 100000))) +
  theme_minimal()

ggplot(HouseRent_Cleaned, aes(x = City, y = Size)) +
  geom_bar(stat = "identity", position = "dodge") +
  ggtitle("Size Distribution by City after cleaning") +
  labs(x = "City", y = "Size") +
  theme_minimal()
#_______________________________________________________________________________________________________
#Data exploration for categorized data
{
#BHK
BHK_Count = as.data.frame(table(HouseRent_Cleaned$BHK))
names(BHK_Count)[1] = "BHK"
print(BHK_Count, row.names = FALSE)

ggplot(BHK_Count, aes(x = BHK, y = Freq)) +
  geom_bar(stat = "identity", fill = c("pink", "lightblue","lightyellow", "lightcyan", "#DDA0DD", "lavender")
           , color = "black") +
  labs(title = "BHK Frequency Counts",
       x = "BHK",
       y = "Frequency") +
  theme_minimal()

plot_ly(BHK_Count, labels =~BHK, values = ~Freq, type = "pie",
        marker = list(colors = c("pink", "lightblue","lightyellow", "lightcyan", "#DDA0DD", "lavender")),
        textinfo = "label+percent",
        hoverinfo = 'text',
        text = ~paste('BHK = ',BHK, '\nFreq = ', Freq))%>%
  layout(showlegend = TRUE,
         legend = list(orientation = 'v', x = 1, y = 0.5),
         title = list(text = "Pie Chart for different number of BHKs", font = list(size = 15), line = -1))

#Area Type
Area.Type_Count = as.data.frame(table(HouseRent_Cleaned$Area.Type))
names(Area.Type_Count)[1] = "Area.Type"
print(Area.Type_Count, row.names = FALSE)

ggplot(Area.Type_Count, aes(x = Area.Type, y = Freq)) +
  geom_bar(stat = "identity", fill = "pink", color = "black") +
  labs(title = "Area.Type Frequency Counts",
       x = "Area.Type",
       y = "Frequency") +
  theme_minimal()

plot_ly(Area.Type_Count, labels =~Area.Type, values = ~Freq, type = "pie",
        marker = list(colors = c("pink", "lightblue")),
        textinfo = "label+percent",
        hoverinfo = 'text',
        text = ~paste('Area.Type = ',Area.Type, '\nFreq = ', Freq))%>%
  layout(showlegend = TRUE,
         legend = list(orientation = 'v', x = 1, y = 0.5),
         title = list(text = "Pie Chart for different Area type", font = list(size = 15)))

#City
City_Count = as.data.frame(table(HouseRent_Cleaned$City))
names(City_Count)[1] = "City"
print(City_Count, row.names = FALSE)

ggplot(City_Count, aes(x = City, y = Freq)) +
  geom_bar(stat = "identity", fill = "lightyellow", color = "black") +
  labs(title = "City Frequency Counts",
       x = "City",
       y = "Frequency") +
  theme_minimal()

plot_ly(City_Count, labels =~City, values = ~Freq, type = "pie",
        marker = list(colors = c("pink", "lightblue","lightyellow", "lightcyan", "#DDA0DD", "lavender")),
        textinfo = "label+percent",
        hoverinfo = 'text',
        text = ~paste('City = ',City, '\nFreq = ', Freq))%>%
  layout(showlegend = TRUE,
         legend = list(orientation = 'v', x = 1, y = 0.5),
         title = list(text = "Pie Chart for different city", font = list(size = 15)))

#Furnishing Status
Furnishing.Status_Count = as.data.frame(table(HouseRent_Cleaned$Furnishing.Status))
names(Furnishing.Status_Count)[1] = "Furnishing.Status"
print(Furnishing.Status_Count, row.names = FALSE)

ggplot(Furnishing.Status_Count, aes(x = Furnishing.Status, y = Freq)) +
  geom_bar(stat = "identity", fill = "lightblue", color = "black") +
  labs(title = "Furnishing.Status Frequency Counts",
       x = "Furnishing.Status",
       y = "Frequency") +
  theme_minimal()

plot_ly(Furnishing.Status_Count, labels =~Furnishing.Status, values = ~Freq, type = "pie",
        marker = list(colors = c("pink", "lightblue","lightyellow")),
        textinfo = "label+percent",
        hoverinfo = 'text',
        text = ~paste('Furnishing.Stauts = ',Furnishing.Status, '\nFreq = ', Freq))%>%
  layout(showlegend = TRUE,
         legend = list(orientation = 'v', x = 1, y = 0.5),
         title = list(text = "Pie Chart for different Furnishing Status", font = list(size = 15)))

#Tenant Preferred
Tenant.Preferred_Count = as.data.frame(table(HouseRent_Cleaned$Tenant.Preferred))
names(Tenant.Preferred_Count)[1] = "Tenant.Preferred"
print(Tenant.Preferred_Count, row.names = FALSE)

ggplot(Tenant.Preferred_Count, aes(x = Tenant.Preferred, y = Freq)) +
  geom_bar(stat = "identity", fill = "pink", color = "black") +
  labs(title = "Tenant.Preferred Frequency Counts",
       x = "Tenant.Preferred",
       y = "Frequency") +
  theme_minimal()

plot_ly(Tenant.Preferred_Count, labels =~Tenant.Preferred, values = ~Freq, type = "pie",
        marker = list(colors = c("pink", "lightblue","lightyellow")),
        textinfo = "label+percent",
        hoverinfo = 'text',
        text = ~paste('Tenant.Preferred = ',Tenant.Preferred, '\nFreq = ', Freq))%>%
  layout(showlegend = TRUE,
         legend = list(orientation = 'v', x = 1, y = 0.5),
         title = list(text = "Pie Chart for different Tenant Preferred", font = list(size = 15)))

#Bathroom
Bathroom_Count = as.data.frame(table(HouseRent_Cleaned$Bathroom))
names(Bathroom_Count)[1] = "Bathroom"
print(Bathroom_Count, row.names = FALSE)

ggplot(Bathroom_Count, aes(x = Bathroom, y = Freq)) +
  geom_bar(stat = "identity", fill = "cyan", color = "black") +
  labs(title = "Bathroom Frequency Counts",
       x = "Bathroom",
       y = "Frequency") +
  theme_minimal()

plot_ly(Bathroom_Count, labels =~Bathroom, values = ~Freq, type = "pie",
        marker = list(colors = c("pink", "lightblue","lightyellow", "lightcyan", "#DDA0DD", "lavender")),
        textinfo = "label+percent",
        hoverinfo = 'text',
        text = ~paste('Bathroom = ',Bathroom, '\nFreq = ', Freq))%>%
  layout(showlegend = TRUE,
         legend = list(orientation = 'v', x = 1, y = 0.5),
         title = list(text = "Pie Chart for different number of Bathrooms", font = list(size = 15)))

#Point of contact
Point.of.Contact_Count = as.data.frame(table(HouseRent_Cleaned$Point.of.Contact))
names(Point.of.Contact_Count)[1] = "Point.of.Contact"
print(Point.of.Contact_Count, row.names = FALSE)

ggplot(Point.of.Contact_Count, aes(x = Point.of.Contact, y = Freq)) +
  geom_bar(stat = "identity", fill = "lightyellow", color = "black") +
  labs(title = "Point.of.Contact Frequency Counts",
       x = "Point.of.Contact",
       y = "Frequency") +
  theme_minimal()

plot_ly(Point.of.Contact_Count, labels =~Point.of.Contact, values = ~Freq, type = "pie",
        marker = list(colors = c("pink", "lightblue","lightyellow", "lightcyan")),
        textinfo = "label+percent",
        hoverinfo = 'text',
        text = ~paste('Point.of.Contact = ',Point.of.Contact, '\nFreq = ', Freq))%>%
  layout(showlegend = TRUE,
         legend = list(orientation = 'v', x = 1, y = 0.5),
         title = list(text = "Pie Chart for different point of contact", font = list(size = 15)))
}
#_______________________________________________________________________________________________________
#Data Visualization
# Create a histogram of Rent


#Create a histogram of Size
ggplot(HouseRent_Cleaned, aes(x = Size)) +
  geom_histogram(binwidth = 1000, color = "black", fill = "lightblue") +
  labs(title = "Distribution of Size",
       x = "Size",
       y = "Frequency")+
  scale_x_continuous(breaks = seq(0, max(HouseRent_Cleaned$Size), by = 1000))


#_______________________________________________________________________________________________________
#Data Pre-processing
HouseRent_Cleaned_Preprocessed = HouseRent_Cleaned

HouseRent_Cleaned_Preprocessed <- HouseRent_Cleaned_Preprocessed %>%
  mutate(Area.Type = case_when(
    Area.Type == "Super Area" ~ 0,
    Area.Type == "Carpet Area" ~ 1,
    Area.Type == "Built Area" ~ 2
  ),
  Furnishing.Status = case_when(
    Furnishing.Status == "Unfurnished" ~ 0,
    Furnishing.Status == "Semi-Furnished" ~ 1,
    Furnishing.Status == "Furnished" ~ 2
  ),
  Point.of.Contact = case_when(
    Point.of.Contact == "Contact Owner" ~ 0,
    Point.of.Contact == "Contact Agent" ~ 1,
    Point.of.Contact == "Contact Builder" ~ 2
  ),
  Tenant.Preferred = case_when(
    Tenant.Preferred == "Family" ~ 0,
    Tenant.Preferred == "Bachelors" ~ 1,
    Tenant.Preferred == "Bachelors/Family" ~ 2
  ))

HouseRent_Cleaned_Preprocessed <- select(HouseRent_Cleaned_Preprocessed, -Posted.On, -Floor, -Area.Locality)

city_subsets_preprocessed <- setNames(replicate(length(unique_cities), NULL), unique_cities)

for(i in unique_cities){
  city_subset_preprocessed = HouseRent_Cleaned_Preprocessed %>% filter(City == i)
  city_subsets_preprocessed[[i]] = city_subset_preprocessed
}
#___________________________________________________________________________________________________
#Objective

#Question 1 How is the distribution of Rent and BHK in each city?
ggplot(data = HouseRent_Cleaned, aes(x = BHK)) +
  geom_histogram(binwidth = 1, color = "black", fill= "pink") +
  facet_wrap(~City) +
  labs(title = "Distribution of BHK in Each City", 
       x = "BHK", 
       y = "Frequency")+
  geom_text(aes(label = ..count..), 
            stat = "count",
            vjust = -0.5,  # Adjust the vertical position of labels
            color = "black", 
            size = 3)

ggplot(HouseRent_Cleaned, aes(x = Rent)) +
  geom_histogram(binwidth = 1000, color = "black", fill = "lightblue") +
  labs(title = "Distribution of Rent in Each City",
       x = "Rent",
       y = "Frequency")+
  facet_wrap(~City)+
  scale_x_continuous(breaks = seq(0, max(HouseRent_Cleaned$Rent), by = 50000))


#Question 2: How does the Rent price changes with different BHK in each city?
ggplot(HouseRent_Cleaned, aes(x = BHK, y = Rent, fill = factor(BHK))) +
  geom_bar(stat = "identity", position = "dodge", color="Black") +
  ggtitle("Rent Distribution by City and BHK") +
  labs(x = "BHK", y = "Rent") +
  scale_fill_discrete(name = "BHK") +
  scale_y_continuous(breaks = (seq(100000, max(HouseRent_Cleaned$Rent), by = 100000))) +
  geom_smooth(aes(group = City), method = loess, color = 'black', linewidth = 1.5)+
  facet_grid(~City)+
  theme_minimal()

ggplot(HouseRent_Cleaned_Preprocessed, aes(x = factor(BHK), y = Rent)) +
  geom_point(aes(color = factor(BHK)))+
  labs(x = "BHK", y = "Rent") +
  scale_color_discrete(name = "BHK") +
  ggtitle("Rent price and BHK for each city")+
  geom_smooth(aes(group = City),method = loess)+
  facet_grid(~City)

#Question 3:Are they any significant difference in Rent distribution based on different BHK?
ggplot(HouseRent_Cleaned_Preprocessed, aes(x = BHK, y = Rent)) +
  geom_boxplot(aes(color = factor(BHK)))+
  stat_summary(
    fun = median, 
    geom = "text", 
    aes(label = round(..y.., 2)), 
    position = position_dodge(width = 0.75),
    vjust = -1,  # Adjust vertical position of text
    color = "black", 
    size = 3)+
  ggtitle("House Rent VS number of BHK for each city")+
  facet_grid(~City)+
  labs(x = "BHK", y = "Rent") +
  scale_color_discrete(name = "BHK")

#Question 4: Is there a correlation between BHK and Rent?
HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  summarize(correlation = cor(BHK, Rent))

#Question 5: Can BHK predict Rent price in each city?
HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  do(anova(lm(Rent ~ BHK, data = .)))


#Quesiton 6: How does the Rent price changes with different BHK in each city?
#BHK, Rent, City and Area.Type
ggplot(HouseRent_Cleaned, aes(x = BHK, y = Rent, fill = factor(Area.Type))) +
  geom_bar(stat = "identity", position = "dodge", color="Black") +
  ggtitle("Rent Distribution by City and BHK") +
  labs(x = "BHK", y = "Rent") +
  scale_fill_discrete(name = "Area.Type") +
  scale_y_continuous(breaks = (seq(100000, max(HouseRent_Cleaned$Rent), by = 100000))) +
  geom_smooth(aes(group = City), method = loess, color = 'black', linewidth = 1.5)+
  facet_grid(~City)+
  theme_minimal()

ggplot(HouseRent_Cleaned, aes(x = City, y = BHK, fill = factor(Area.Type))) +
  geom_point(aes(size = Rent), shape = 21, color = "black") +
  scale_fill_manual(values = c("Super Area" = "lightblue", "Carpet Area" = "blue", "Built Area" = "black")) +
  scale_size_continuous(range = c(5, 15)) +  # Adjust the range for bubble sizes
  labs(x = "City", y = "BHK", fill = "Area Type", size = "Rent") +
  ggtitle("Bubble Plot: City vs BHK by Area Type and Rent") +
  theme_minimal()

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  summarize(correlation = cor(Area.Type, Rent))

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  do(anova(lm(Rent ~ Area.Type, data = .)))

#Question 7: How is the relationship between BHK and Rent in different Size across Cities
ggpairs(data = HouseRent_Cleaned,
        columns = c("BHK", "Rent", "Size"),
        aes(color = City),
        title = "Pair Plot for BHK, Rent, Size, and City")


ggplot(HouseRent_Cleaned_Preprocessed, aes(x = Size, y = Rent, z = factor(BHK), color = factor(BHK))) +
  geom_point(size = 3) +
  scale_color_discrete(name = "BHK") +
  labs(x = "Size", y = "Rent", z = "BHK") +
  facet_wrap(~City)

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  summarize(correlation = cor(Size, Rent))

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  do(anova(lm(Rent ~ Size, data = .)))

#Question 8: How is the relationship between BHK and Rent in different Tenant Preferred across Cities
ggplot(HouseRent_Cleaned, aes(x = BHK, y = Rent, fill = Tenant.Preferred)) +
  geom_violin(scale = "width", trim = FALSE) +
  labs(x = "BHK", y = "Rent") +
  scale_fill_manual(values = c("Family" = "darkblue", "Bachelors" = "blue", "Bachelors/Family" = "lightblue")) +
  facet_grid(~ City) +
  theme_minimal()

ggplot(HouseRent_Cleaned, aes(x = factor(BHK), y = Rent, color = Tenant.Preferred)) +
  geom_point() +
  labs(x = "BHK", y = "Rent") +
  scale_color_manual(values = c("Family" = "darkblue", "Bachelors" = "blue", "Bachelors/Family" = "lightblue")) +
  facet_grid(~ City) +
  theme_minimal()

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  summarize(correlation = cor(Tenant.Preferred, Rent))

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  do(anova(lm(Rent ~ Tenant.Preferred, data = .)))

#Question 9: How is the relationship changes between BHK and Rent with different Point of Contact in each cities
ggplot(HouseRent_Cleaned, aes(x = Rent, fill = Point.of.Contact)) +
  geom_density(alpha = 0.5) +
  labs(x = "Rent") +
  scale_fill_manual(values = c("Contact Owner" = "darkblue", "Contact Builder" = "blue", "Contact Agent" = "lightblue")) +
  facet_wrap(~ City) +
  theme_minimal()

ggplot(HouseRent_Cleaned, aes(x = Rent, fill = factor(BHK))) +
  geom_density(alpha = 0.5) +
  labs(x = "Rent") +
  scale_fill_manual(values = c('1' = 'red', '2' = 'orange', '3' = 'yellow', '4' = 'green', '5' = 'lightblue', '6' = 'purple')) +
  facet_wrap(~ City) +
  theme_minimal()

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  summarize(correlation = cor(Point.of.Contact, Rent))

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  do(anova(lm(Rent ~ Point.of.Contact, data = .)))

#Question 10: How is the relationship between Rent and BHK with a changes of Bathroom for each city
ggplot(HouseRent_Cleaned, aes(x = Bathroom, y = Rent, fill = factor(BHK))) +
  geom_violin(scale = "width", trim = TRUE, position = 'dodge') +
  labs(x = "Bathroom", y = "Rent") +
  scale_fill_manual(values = c('1' = 'red', '2' = 'orange', '3' = 'yellow', '4' = 'green', '5' = 'lightblue', '6' = 'purple'))+
  facet_wrap(~City)

ggplot(HouseRent_Cleaned, aes(x = Bathroom, y = Rent, fill = factor(BHK))) +
  geom_bar(stat = "identity") +
  labs(x = "Bathroom", y = "Rent") +
  scale_fill_manual(values = c('1' = 'red', '2' = 'orange', '3' = 'yellow', '4' = 'green', '5' = 'lightblue', '6' = 'purple')) +
  facet_wrap(~ City) +
  theme_minimal()

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  summarize(correlation = cor(Bathroom, Rent))

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  do(anova(lm(Rent ~ Bathroom, data = .)))

#Question 11: How is the relationship between BHK and Rent with different furnishing status in each city
unique_BHK = unique(HouseRent_Cleaned$BHK)

BHK_subsets <- setNames(replicate(length(unique_BHK), NULL), unique_BHK)

for(i in unique_BHK){
  BHK_subset = HouseRent_Cleaned %>% filter(BHK == i)
  BHK_subsets[[i]] = BHK_subset
}

#BHK 1
{
BHK_1_fur = as.data.frame(table(BHK_subsets$'1'$Furnishing.Status))
names(BHK_1_fur)[1] = "Furnishing.Status"

BHK1 = plot_ly(
  data = BHK_1_fur,
  labels = ~Furnishing.Status,
  values = ~Freq,
  type = 'pie',
  hole = 0.4,
  textinfo = "label+percent",
  hoverinfo = 'text', 
  text = ~paste('Furnishing Status = ',Furnishing.Status, '\nFreq = ',Freq),
  marker = list(colors = c("lightblue", "blue", "darkblue"))
)%>%
  layout(
    showlegend = TRUE,
    title = "Furnishing Status in 1 BHK", # Set the title
    legend = list(orientation = "h", x = 0.5, y = -0.1), # Customize the legend position
    annotations = list(text = "BHK 1", x = 0.5, y = 0.5, showarrow = FALSE) # Annotation
  )}

#BHK 2
{
BHK_2_fur = as.data.frame(table(BHK_subsets$'2'$Furnishing.Status))
names(BHK_2_fur)[1] = "Furnishing.Status"

BHK2 = plot_ly(
  data = BHK_2_fur,
  labels = ~Furnishing.Status,
  values = ~Freq,
  type = 'pie',
  hole = 0.4,
  textinfo = "label+percent",
  hoverinfo = 'text', 
  text = ~paste('Furnishing Status = ',Furnishing.Status, '\nFreq = ',Freq),
  marker = list(colors = c("lightblue", "blue", "darkblue")) # Specify colors
)%>%
  layout(
    showlegend = TRUE,
    title = "Furnishing Status in 2 BHK", # Set the title
    legend = list(orientation = "h", x = 0.5, y = -0.1), # Customize the legend position
    annotations = list(text = "BHK 2", x = 0.5, y = 0.5, showarrow = FALSE) # Annotation
  )
}

#BHK 3
{
BHK_3_fur = as.data.frame(table(BHK_subsets$'3'$Furnishing.Status))
names(BHK_3_fur)[1] = "Furnishing.Status"

BHK3 = plot_ly(
  data = BHK_3_fur,
  labels = ~Furnishing.Status,
  values = ~Freq,
  type = 'pie',
  hole = 0.4,
  textinfo = "label+percent",
  hoverinfo = 'text', 
  text = ~paste('Furnishing Status = ',Furnishing.Status, '\nFreq = ',Freq),
  marker = list(colors = c("lightblue", "blue", "darkblue")) # Specify colors
)%>%
  layout(
    showlegend = TRUE,
    title = "Furnishing Status in 3 BHK", # Set the title
    legend = list(orientation = "h", x = 0.5, y = -0.1), # Customize the legend position
    annotations = list(text = "BHK 3", x = 0.5, y = 0.5, showarrow = FALSE) # Annotation
  )
}

#BHK 4
{BHK_4_fur = as.data.frame(table(BHK_subsets$'4'$Furnishing.Status))
  names(BHK_4_fur)[1] = "Furnishing.Status"
  
  BHK4 = plot_ly(
    data = BHK_4_fur,
    labels = ~Furnishing.Status,
    values = ~Freq,
    type = 'pie',
    hole = 0.4,
    textinfo = "label+percent",
    hoverinfo = 'text', 
    text = ~paste('Furnishing Status = ',Furnishing.Status, '\nFreq = ',Freq),
    marker = list(colors = c("lightblue", "blue", "darkblue")) # Specify colors
  )%>%
    layout(
      showlegend = TRUE,
      title = "Furnishing Status in 4 BHK", # Set the title
      legend = list(orientation = "h", x = 0.5, y = -0.1), # Customize the legend position
      annotations = list(text = "BHK 4", x = 0.5, y = 0.5, showarrow = FALSE) # Annotation
    )}

#BHK 5
{BHK_5_fur = as.data.frame(table(BHK_subsets$'5'$Furnishing.Status))
  names(BHK_5_fur)[1] = "Furnishing.Status"
  
  BHK5 = plot_ly(
    data = BHK_5_fur,
    labels = ~Furnishing.Status,
    values = ~Freq,
    type = 'pie',
    hole = 0.4,
    textinfo = "label+percent",
    hoverinfo = 'text', 
    text = ~paste('Furnishing Status = ',Furnishing.Status, '\nFreq = ',Freq),
    marker = list(colors = c("lightblue", "blue", "darkblue")) # Specify colors
  )%>%
    layout(
      showlegend = TRUE,
      title = "Furnishing Status in 5 BHK", # Set the title
      legend = list(orientation = "h", x = 0.5, y = -0.1), # Customize the legend position
      annotations = list(text = "BHK 5", x = 0.5, y = 0.5, showarrow = FALSE) # Annotation
    )}

#BHK 6
{BHK_6_fur = as.data.frame(table(BHK_subsets$'6'$Furnishing.Status))
  names(BHK_6_fur)[1] = "Furnishing.Status"
  
  BHK6 = plot_ly(
    data = BHK_6_fur,
    labels = ~Furnishing.Status,
    values = ~Freq,
    type = 'pie',
    hole = 0.4,
    textinfo = "label+percent",
    hoverinfo = 'text', 
    text = ~paste('Furnishing Status = ',Furnishing.Status, '\nFreq = ',Freq),
    marker = list(colors = c("lightblue", "blue", "darkblue")) # Specify colors
  )%>%
    layout(
      showlegend = TRUE,
      title = "Furnishing Status in 6 BHK", # Set the title
      legend = list(orientation = "h", x = 0.5, y = -0.1), # Customize the legend position
      annotations = list(text = "BHK 6", x = 0.5, y = 0.5, showarrow = FALSE) # Annotation
    )}

BHK1
BHK2
BHK3
BHK4
BHK5
BHK6

ggplot(HouseRent_Cleaned, aes(x = BHK, y = Rent, fill = factor(Furnishing.Status))) +
  geom_bar(stat = "identity", position = "dodge", color="Black") +
  ggtitle("Rent Distribution by City and BHK") +
  labs(x = "BHK", y = "Rent") +
  scale_fill_discrete(name = "Furnishing Status") +
  scale_y_continuous(breaks = (seq(100000, max(HouseRent_Cleaned$Rent), by = 100000))) +
  geom_smooth(aes(group = City), method = loess, color = 'black', linewidth = 1.5)+
  facet_grid(~City)+
  theme_minimal()

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  summarize(correlation = cor(Furnishing.Status, Rent))

HouseRent_Cleaned_Preprocessed %>%
  group_by(City) %>%
  do(anova(lm(Rent ~ Furnishing.Status, data = .)))
#___________________________________________________________________________________________________
#Correlation of each attributes with Rent
{
#Kolkata
#Correlation highest: BHK, Size, Bathroom
ggpairs(city_subsets_preprocessed$Kolkata, title = "BHK and Rent in Kolkata",columns = c("BHK", "Rent"))#0.554
ggpairs(city_subsets_preprocessed$Kolkata, title = "Size and Rent in Kolkata",columns = c("Size", "Rent"))#0.604
ggpairs(city_subsets_preprocessed$Kolkata, title = "Point of Contact and Rent in Kolkata",columns = c("Point.of.Contact", "Rent"))#0.210
ggpairs(city_subsets_preprocessed$Kolkata, title = "Furnishing Status and Rent in Kolkata",columns = c("Furnishing.Status", "Rent"))#0.119
ggpairs(city_subsets_preprocessed$Kolkata, title = "Tenant Preferred and Rent in Kolkata",columns = c("Tenant.Preferred", "Rent"))#-0.065
ggpairs(city_subsets_preprocessed$Kolkata, title = "Bathroom and Rent in Kolkata",columns = c("Bathroom", "Rent"))#0.562
ggpairs(city_subsets_preprocessed$Kolkata, title = "Area Type and Rent in Kolkata",columns = c("Area.Type", "Rent"))#0.027

HouseRent_Cleaned_Preprocessed_Kolkata = city_subsets_preprocessed$Kolkata
HouseRent_Cleaned_Preprocessed_Kolkata <- select(HouseRent_Cleaned_Preprocessed_Kolkata, -City)

cor_matrix_Kolkata = cor(HouseRent_Cleaned_Preprocessed_Kolkata)

corrplot(cor_matrix_Kolkata, method = "color", addCoef.col = "black", tl.col = "black")

title("Correlation Heatmap for Kolkata", line = 3)
#___________________________________________________________________________________________________
#Mumbai
#Correlation highest: BHK, Size, Bathroom
ggpairs(city_subsets_preprocessed$Mumbai, title = "BHK and Rent in Mumbai",columns = c("BHK", "Rent"))#0.733
ggpairs(city_subsets_preprocessed$Mumbai, title = "Size and Rent in Mumbai",columns = c("Size", "Rent"))#0.860
ggpairs(city_subsets_preprocessed$Mumbai, title = "Point of Contact and Rent in Mumbai",columns = c("Point.of.Contact", "Rent"))#0.297
ggpairs(city_subsets_preprocessed$Mumbai, title = "Furnishing Status and Rent in Mumbai",columns = c("Furnishing.Status", "Rent"))#0.260
ggpairs(city_subsets_preprocessed$Mumbai, title = "Tenant Preferred and Rent in Mumbai",columns = c("Tenant.Preferred", "Rent"))#-0.001
ggpairs(city_subsets_preprocessed$Mumbai, title = "Bathroom and Rent in Mumbai",columns = c("Bathroom", "Rent"))#0.740
ggpairs(city_subsets_preprocessed$Mumbai, title = "Area Type and Rent in Mumbai",columns = c("Area.Type", "Rent"))#0.216

HouseRent_Cleaned_Preprocessed_Mumbai = city_subsets_preprocessed$Mumbai
HouseRent_Cleaned_Preprocessed_Mumbai <- select(HouseRent_Cleaned_Preprocessed_Mumbai, -City)

cor_matrix_Mumbai = cor(HouseRent_Cleaned_Preprocessed_Mumbai)

corrplot(cor_matrix_Mumbai, method = "color", addCoef.col = "black", tl.col = "black")

title("Correlation Heatmap for Mumbai", line = 3)
#___________________________________________________________________________________________________
#Bangalore
#Correlation highest: BHK, Size, Bathroom
ggpairs(city_subsets_preprocessed$Bangalore, title = "BHK and Rent in Bangalore",columns = c("BHK", "Rent"))#0.620
ggpairs(city_subsets_preprocessed$Bangalore, title = "Size and Rent in Bangalore",columns = c("Size", "Rent"))#0.820
ggpairs(city_subsets_preprocessed$Bangalore, title = "Point of Contact and Rent in Bangalore",columns = c("Point.of.Contact", "Rent"))#0.482
ggpairs(city_subsets_preprocessed$Bangalore, title = "Furnishing Status and Rent in Bangalore",columns = c("Furnishing.Status", "Rent"))#0.151
ggpairs(city_subsets_preprocessed$Bangalore, title = "Tenant Preferred and Rent in Bangalore",columns = c("Tenant.Preferred", "Rent"))#-0.174
ggpairs(city_subsets_preprocessed$Bangalore, title = "Bathroom and Rent in Bangalore",columns = c("Bathroom", "Rent"))#0.674
ggpairs(city_subsets_preprocessed$Bangalore, title = "Area Type and Rent in Bangalore",columns = c("Area.Type", "Rent"))#0.254

HouseRent_Cleaned_Preprocessed_Bangalore = city_subsets_preprocessed$Bangalore
HouseRent_Cleaned_Preprocessed_Bangalore <- select(HouseRent_Cleaned_Preprocessed_Bangalore, -City)

cor_matrix_Bangalore = cor(HouseRent_Cleaned_Preprocessed_Bangalore)

corrplot(cor_matrix_Bangalore, method = "color", addCoef.col = "black", tl.col = "black")

title("Correlation Heatmap for Bangalore", line = 3)

#___________________________________________________________________________________________________
#Delhi
#Correlation highest: BHK, Size, Bathroom
ggpairs(city_subsets_preprocessed$Delhi, title = "BHK and Rent in Delhi",columns = c("BHK", "Rent"))#0.588
ggpairs(city_subsets_preprocessed$Delhi, title = "Size and Rent in Delhi",columns = c("Size", "Rent"))#0.615
ggpairs(city_subsets_preprocessed$Delhi, title = "Point of Contact and Rent in Delhi",columns = c("Point.of.Contact", "Rent"))#0.353
ggpairs(city_subsets_preprocessed$Delhi, title = "Furnishing Status and Rent in Delhi",columns = c("Furnishing.Status", "Rent"))#0.147
ggpairs(city_subsets_preprocessed$Delhi, title = "Tenant Preferred and Rent in Delhi",columns = c("Tenant.Preferred", "Rent"))#-0.191
ggpairs(city_subsets_preprocessed$Delhi, title = "Bathroom and Rent in Delhi",columns = c("Bathroom", "Rent"))#0.718
ggpairs(city_subsets_preprocessed$Delhi, title = "Area Type and Rent in Delhi",columns = c("Area.Type", "Rent"))#0.224

HouseRent_Cleaned_Preprocessed_Delhi = city_subsets_preprocessed$Delhi
HouseRent_Cleaned_Preprocessed_Delhi <- select(HouseRent_Cleaned_Preprocessed_Delhi, -City)

cor_matrix_Delhi = cor(HouseRent_Cleaned_Preprocessed_Delhi)

corrplot(cor_matrix_Delhi, method = "color", addCoef.col = "black", tl.col = "black")

title("Correlation Heatmap for Delhi", line = 3)

#___________________________________________________________________________________________________
#Chennai
#Correlation highest: BHK, Size, Bathroom
ggpairs(city_subsets_preprocessed$Chennai, title = "BHK and Rent in Chennai",columns = c("BHK", "Rent"))#0.583
ggpairs(city_subsets_preprocessed$Chennai, title = "Size and Rent in Chennai",columns = c("Size", "Rent"))#0.738
ggpairs(city_subsets_preprocessed$Chennai, title = "Point of Contact and Rent in Chennai",columns = c("Point.of.Contact", "Rent"))#0.565
ggpairs(city_subsets_preprocessed$Chennai, title = "Furnishing Status and Rent in Chennai",columns = c("Furnishing.Status", "Rent"))#0.251
ggpairs(city_subsets_preprocessed$Chennai, title = "Tenant Preferred and Rent in Chennai",columns = c("Tenant.Preferred", "Rent"))#-0.119
ggpairs(city_subsets_preprocessed$Chennai, title = "Bathroom and Rent in Chennai",columns = c("Bathroom", "Rent"))#0.587
ggpairs(city_subsets_preprocessed$Chennai, title = "Area Type and Rent in Chennai",columns = c("Area.Type", "Rent"))#0.181

HouseRent_Cleaned_Preprocessed_Chennai = city_subsets_preprocessed$Chennai
HouseRent_Cleaned_Preprocessed_Chennai <- select(HouseRent_Cleaned_Preprocessed_Chennai, -City)

cor_matrix_Chennai = cor(HouseRent_Cleaned_Preprocessed_Chennai)

corrplot(cor_matrix_Chennai, method = "color", addCoef.col = "black", tl.col = "black")

title("Correlation Heatmap for Chennai", line = 3)

#___________________________________________________________________________________________________
#Hyderabad
#Correlation highest: BHK, Size, Bathroom
ggpairs(city_subsets_preprocessed$Hyderabad, title = "BHK and Rent in Hyderabad",columns = c("BHK", "Rent"))#0.593
ggpairs(city_subsets_preprocessed$Hyderabad, title = "Size and Rent in Hyderabad",columns = c("Size", "Rent"))#0.732
ggpairs(city_subsets_preprocessed$Hyderabad, title = "Point of Contact and Rent in Hyderabad",columns = c("Point.of.Contact", "Rent"))#0.521
ggpairs(city_subsets_preprocessed$Hyderabad, title = "Furnishing Status and Rent in Hyderabad",columns = c("Furnishing.Status", "Rent"))#0.267
ggpairs(city_subsets_preprocessed$Hyderabad, title = "Tenant Preferred and Rent in Hyderabad",columns = c("Tenant.Preferred", "Rent"))#-0.227
ggpairs(city_subsets_preprocessed$Hyderabad, title = "Bathroom and Rent in Hyderabad",columns = c("Bathroom", "Rent"))#0.626
ggpairs(city_subsets_preprocessed$Hyderabad, title = "Area Type and Rent in Hyderabad",columns = c("Area.Type", "Rent"))#0.226

HouseRent_Cleaned_Preprocessed_Hyderabad = city_subsets_preprocessed$Hyderabad
HouseRent_Cleaned_Preprocessed_Hyderabad <- select(HouseRent_Cleaned_Preprocessed_Hyderabad, -City)

cor_matrix_Hyderabad = cor(HouseRent_Cleaned_Preprocessed_Hyderabad)

corrplot(cor_matrix_Hyderabad, method = "color", addCoef.col = "black", tl.col = "black")

title("Correlation Heatmap for Hyderabad", line = 3)
}
#_______________________________________________________________________________________________________
#ANOVA
{
#ANOVA for Kolkata
#Result for p-value in Kolkata
summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#2*10^(-16)
summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#2*10^(-16)
summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#1.38*10^(-6)
summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#0.00642
summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#0.137
summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))#2*10^(-16)
summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Kolkata))# 0.545

ANOVA_attribute <- c("BHK", "Size", "Point.of.Contact", "Furnishing.Status", "Tenant.Preferred", "Bathroom", "Area.Type")
ANOVA_p_scores_Kolkata <- c(2 * 10^(-16), 2 * 10^(-16), 1.38 * 10^(-6), 0.00642, 0.137, 2 * 10^(-16), 0.545)
ANOVA_p_scores_df_Kolkata <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Kolkata)

ggplot(ANOVA_p_scores_df_Kolkata, aes(x = Attribute, y = P_Value)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "ANOVA P-Values for Each Attribute in Kolkata",
       x = "Attribute", y = "P-Value") +
  scale_y_log10()
#_______________________________________________________________________________________________________
#ANOVA for Mumbai
#Result for p-value in Mumbai
summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2*10^(-16)
summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2*10^(-16)
summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2*10^(-16)
summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2.75*10^(-16)
summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#0.98
summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#2*10^(-16)
summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Mumbai))#1.26*10^(-11)

ANOVA_p_scores_Mumbai <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 2.75 * 10^(-16), 0.98, 2 * 10^(-16), 1.26 * 10^(-11))
ANOVA_p_scores_df_Mumbai <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Mumbai)

ggplot(ANOVA_p_scores_df_Mumbai, aes(x = Attribute, y = P_Value)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "ANOVA P-Values for Each Attribute in Mumbai",
       x = "Attribute", y = "P-Value") +
  scale_y_log10()
#_______________________________________________________________________________________________________
#ANOVA for Bangalore
#Result for p-value in Bangalore
summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#2*10^(-16)
summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#2*10^(-16)
summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#2*10^(-16)
summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#6.42*10^(-6)
summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#1.95*10^(-7)
summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#2*10^(-16)
summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Bangalore))#1.78*10^(-14)

ANOVA_p_scores_Bangalore <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 6.42*10^(-6), 1.95*10^(-7), 2*10^(-16), 1.78*10^(-14))
ANOVA_p_scores_df_Bangalore <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Bangalore)

ggplot(ANOVA_p_scores_df_Bangalore, aes(x = Attribute, y = P_Value)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "ANOVA P-Values for Each Attribute in Bangalore",
       x = "Attribute", y = "P-Value") +
  scale_y_log10()

#_______________________________________________________________________________________________________
#ANOVA for Delhi
#Result for p-value in Delhi
summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#2*10^(-16)
summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#2*10^(-16)
summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#2*10^(-16)
summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#0.00035
summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#3.22*10^(-6)
summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#2*10^(-16)
summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Delhi))#4.29*10^(-8)

ANOVA_p_scores_Delhi <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 0.00035, 3.22*10^(-6), 2*10^(-16), 4.29*10^(-8))
ANOVA_p_scores_df_Delhi <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Delhi)

ggplot(ANOVA_p_scores_df_Delhi, aes(x = Attribute, y = P_Value)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "ANOVA P-Values for Each Attribute in Delhi",
       x = "Attribute", y = "P-Value") +
  scale_y_log10()

#_______________________________________________________________________________________________________
#ANOVA for Chennai
#Result for p-value in Chennai
summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#2*10^(-16)
summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#2*10^(-16)
summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#2*10^(-16)
summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#3.83*10^(-14)
summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#0.000389
summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#2*10^(-16)
summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Chennai))#6.39*10^(-8)

ANOVA_p_scores_Chennai <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 3.83*10^(-14), 0.000389, 2 * 10^(-16), 6.39*10^(-8))
ANOVA_p_scores_df_Chennai <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Chennai)

ggplot(ANOVA_p_scores_df_Chennai, aes(x = Attribute, y = P_Value)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "ANOVA P-Values for Each Attribute in Chennai",
       x = "Attribute", y = "P-Value") +
  scale_y_log10()

#_______________________________________________________________________________________________________
#ANOVA for Hyderabad
#Result for p-value in Hyderabad
summary(aov(BHK~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
summary(aov(Size~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
summary(aov(Point.of.Contact~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
summary(aov(Furnishing.Status~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#1.34*10^(-15)
summary(aov(Tenant.Preferred~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
summary(aov(Bathroom~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#2*10^(-16)
summary(aov(Area.Type~Rent, data = HouseRent_Cleaned_Preprocessed_Hyderabad))#1.85*10^(-11)

ANOVA_p_scores_Hyderabad <- c(2 * 10^(-16), 2 * 10^(-16), 2 * 10^(-16), 1.34*10^(-15), 2*10^(-16), 2 * 10^(-16), 1.85*10^(-11))
ANOVA_p_scores_df_Hyderabad <- data.frame(Attribute = ANOVA_attribute, P_Value = ANOVA_p_scores_Hyderabad)

ggplot(ANOVA_p_scores_df_Hyderabad, aes(x = Attribute, y = P_Value)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "ANOVA P-Values for Each Attribute in Hyderabad",
       x = "Attribute", y = "P-Value") +
  scale_y_log10()
}
#_______________________________________________________________________________________________________
#Linear Regression Model

# Set a random seed for reproducibility
set.seed(123)

# Define the proportion of data for the training set (e.g., 70%)
train_proportion <- 0.7

# Calculate the number of samples for the training set
num_train <- round(nrow(HouseRent_Cleaned_Preprocessed) * train_proportion)

# Create an index vector for random sampling
sample_indices <- sample(seq_len(nrow(HouseRent_Cleaned_Preprocessed)), size = num_train)

# Create the training dataset
train_data <- HouseRent_Cleaned_Preprocessed[sample_indices, ]

# Create the testing dataset by excluding samples used in training
test_data <- HouseRent_Cleaned_Preprocessed[-sample_indices, ]

# Train a linear regression model
model <- lm(Rent ~ BHK + Size +  Point.of.Contact + Bathroom +Furnishing.Status + Point.of.Contact, data = train_data)

# Make predictions on the test data
predictions <- predict(model, newdata = test_data)

# Evaluate the model
mse <- mean((test_data$Rent - predictions)^2)
rmse <- sqrt(mse)
r_squared <- 1 - (sum((test_data$Rent - predictions)^2) / sum((test_data$Rent - mean(test_data$Rent))^2))

# Print evaluation metrics
cat("Mean Squared Error:", mse, "\n")
cat("Root Mean Squared Error:", rmse, "\n")
cat("R-squared:", r_squared, "\n")
#_______________________________________________________________________________________________________
#Random Forest
# Set a random seed for reproducibility
set.seed(456)

# Create a vector of random indices for training data
train_indices <- sample(1:nrow(HouseRent_Cleaned_Preprocessed), size = 0.7 * nrow(HouseRent_Cleaned_Preprocessed))

# Split the data
X_train <- HouseRent_Cleaned_Preprocessed[train_indices,]
y_train <- HouseRent_Cleaned_Preprocessed$Rent[train_indices]
X_test <- HouseRent_Cleaned_Preprocessed[-train_indices,]
y_test <- HouseRent_Cleaned_Preprocessed$Rent[-train_indices]


# Train the random forest model
rf_model <- randomForest(y_train ~ ., data = X_train)

# Make predictions
rf_prediction <- predict(rf_model, newdata = X_test)

# Calculate Mean Absolute Error (MAE)
mae_rf <- mean(abs(rf_prediction - y_test))

# Calculate Mean Squared Error (MSE)
mse_rf <- mean((rf_prediction - y_test)^2)

# Calculate Root Mean Squared Error (RMSE)
rmse_rf <- sqrt(mse_rf)

# Calculate R-squared
r_squared_rf <- 1 - sum((rf_prediction - y_test)^2) / sum((y_test - mean(y_test))^2)

# Print evaluation metrics
cat("Random Forest Model Evaluation:\n")
cat("Mean Absolute Error:", mae_rf, "\n")
cat("Mean Squared Error:", mse_rf, "\n")
cat("Root Mean Squared Error:", rmse_rf, "\n")
cat("R-squared:", r_squared_rf, "\n")

#________________________________________________________________________________________________________
#Bar chart can only have one continuous and one categorical
#Anything which not taught in class will see as an additional features
